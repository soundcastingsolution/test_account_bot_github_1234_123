﻿function localizedMessages(message) {
    switch (message) {
        case "$Localized:ChatSessionEnded":
            return "Chat session ended";
            break;
        case "$Localized:AgentLeftChat":
            return "The agent has left the chat.";
            break;
        default:
            return message;
    }
}

function Message(partyType, timeStamp, message, label) {
    var self = this;

    self.partyType = ko.observable(partyType);
    self.messageTime = timeStamp;
    self.timestamp = ko.observable("(" + new Date(timeStamp).toLocaleTimeString() + ")");
    self.message = ko.observable(message);
    self.label = ko.computed(function () {
        if (label == "" || label == undefined) {
            return partyType;
        }
        else {
            return label;
        }
    }, this);
}

function ChatRoomModel(room, roomStatus, roomStartTime, contact, roomSelected) {
    var self = this;

    self.skillName = ko.observable("");
    self.status = ko.observable(roomStatus);
    self.roomId = ko.observable(room);
    self.roomName = ko.observable("Room " + room);
    self.contactId = ko.observable(contact);
    self.startTime = ko.observable(roomStartTime);
    self.chatMessages = ko.observableArray([]);
    self.selected = ko.observable(roomSelected);

    self.chatStatusType = ko.observable();

    self.chatMessageTimer;
    self.messageTimeElapsed = ko.observable("00:00");

    self.chatStatusIcon = ko.computed(function () {
        if (self.chatStatusType() == "Client") {
            return "../images/icon_feedback.png";
        }
        else {
            return "../images/icon_waiting.png";
        }
    }, this);

    self.highlightedStyle = ko.observable("");

}

function chatViewModel(onError) {
    var self = this;

    self.chatGlobalTimer;
    self.chatStatusTimer;
    self.skillQueueTimerId;

    //Constant for difference between Server Time and client time
    self.serverTimeOffset = ko.observable(0);
    self.updateServerTimeOffsetId;

    self.globalTimeElapsed = ko.observable("00:00");
    self.statusTimeElapsed = ko.observable("00:00");

    self.message = ko.observable();

    self.chatRooms = ko.observableArray();
    self.selectedRoom = ko.observable();

    self.chatVisible = ko.computed(function () {
        if (self.chatRooms().length >= 1) {
            return true;
        }
        else {
            return false;
        }

    }, this);

    self.showEndChatButton = ko.observable(false);
    self.newButtonEnabled = ko.observable(false);

    self.boldFormat = ko.observable(false);
    self.italicFormat = ko.observable(false);
    self.underlineFormat = ko.observable(false);

    self.chatSkillsList = ko.observableArray(); // change to observable array
    self.selectedTargetSkill = ko.observable("");

    self.transferDialogVisible = ko.observable(false);
    self.incomingChatDialogVisible = ko.observable(false);
    self.chatTransferValidationVisible = ko.observable(false);

    self.messageFormat = ko.computed(function () {
        var style = "";
        if (self.boldFormat()) {
            style = "boldStyle";
        }
        if (self.italicFormat()) {
            if (style != "") {
                style += " ";
            }
            style += "italicStyle";
        }
        if (self.underlineFormat()) {
            if (style != "") {
                style += " ";
            }
            style += "underlineStyle";
        }
        return style;
    }, this);

    self.updateChat = function (event) {
        stopTimer(self.chatStatusTimer);
        self.statusTimeElapsed("00:00");
        self.chatStatusTimer = startTimer(self.statusTimeElapsed, event.lastStateChangeTime);

        var chatRoom = self.getChatRoom(event.roomId);
        if (chatRoom == null) {
            self.AddRoom(event.roomId, event.status, event.startTime, event.contactID, event.skill);
            chatRoom = self.getChatRoom(event.roomId);
            chatRoom.chatMessageTimer = startTimer(chatRoom.messageTimeElapsed, event.startTime); // initialize messagetimer
        }
        else if (chatRoom != null && chatRoom.status() == "Disconnected") {
            self.AddRoom(event.roomId, event.status, event.startTime, event.contactID, event.skill);
        }
        if (chatRoom != null) {
            chatRoom.status(event.status);
        }
        self.showMessages(event);
    }


    self.activeChat = function (event) {
        var chatRoom = self.getChatRoom(event.roomId);

        stopTimer(self.chatStatusTimer);
        self.chatStatusTimer = startTimer(self.statusTimeElapsed, event.lastStateChangeTime);
        stopTimer(self.chatGlobalTimer);
        self.chatGlobalTimer = startTimer(self.globalTimeElapsed, chatRoom.startTime());

        chatRoom.selected(true);
        self.showEndChatButton(true);

        //Format toogle buttons
        $("#messageFormat").buttonset();

        if (self.chatRooms().length === 1) {
            startCheckSkillQueueTimer();
        }
    }

    self.disconnectChat = function (event) {
        var chatRoom = self.getChatRoom(event.roomId);
        if (chatRoom != null)
            chatRoom.status(event.status);

        setTimeout(function () {
            self.chatRooms.remove(function (item) {
                return item.contactId() == event.contactID
            });

            if (self.chatRooms().length === 0) {
                stopTimer(self.chatGlobalTimer);
                stopTimer(self.chatStatusTimer);
                stopTimer(self.chatMessageTimer);
                stopCheckSkillQueueTimer();
            }
        }, 4000);
    }

    self.acceptChat = function (event) {
        icAgentAPI.acceptChat(event.contactID, null, onError);
    }

    self.rejectChat = function (event) {
        icAgentAPI.rejectChat(event.contactID, null, onError);
    }

    self.endChat = function () {
        icAgentAPI.endChat(self.selectedRoom().contactId(), null, onError);
    }

    self.addChat = function () {
        icAgentAPI.addChat(null, null);
    }

    self.transferChat = function () {
        self.transferDialogVisible(true);
        self.incomingChatDialogVisible(true);
        $("#transferDialog-form").dialog({
            minHeight: 160,
            width: 300,
            modal: true,
            open: function (event, ui) {
                icAgentAPI.getSkillList(onGetSkillsSuccess, null);
                function onGetSkillsSuccess(skills) {
                    $.each(skills, function (index, value) {
                        if (this.mediaTypeId == 3 && this.isActive == "True") {
                            self.chatSkillsList.push(this.skillName);
                        }
                    });
                }
            },
            buttons: {
                "Transfer": function () {
                    var bValid = true;
                    $("#skillName").removeClass("ui-state-error");
                    self.selectedTargetSkill($.trim(self.selectedTargetSkill()));
                    if (bValid && self.selectedTargetSkill() != "") {
                        self.chatTransferValidationVisible(false);
                        icAgentAPI.transferChat(self.selectedRoom().contactId(), self.selectedTargetSkill(), null, onError);
                        $(this).dialog("close");
                        self.incomingChatDialogVisible(false);
                    }
                    else {
                        $("#skillName").addClass("ui-state-error");
                        self.chatTransferValidationVisible(true);
                    }
                },
                Cancel: function () {
                    $(this).dialog("close");
                    self.incomingChatDialogVisible(false);
                }
            },
            close: function () {
                $("#skillName").val("").removeClass("ui-state-error");
                self.chatTransferValidationVisible(false);
                self.chatSkillsList.removeAll()
            }
        });
    }

    self.AddRoom = function (roomId, status, startTime, contactID, skill) {
        newRoom = new ChatRoomModel(roomId, status, startTime, contactID, false);
        self.chatRooms.push(newRoom);
        self.selectedRoom(newRoom);
        updateContactSkill(newRoom, skill);
        self.newButtonEnabled(false);
    }

    self.sendMessage = function () {
        if (self.message() == "" || self.message() == undefined)
            return;

        if (self.boldFormat()) {
            self.message("<B>" + self.message() + "</B>");
        }
        if (self.italicFormat()) {
            self.message("<I>" + self.message() + "</I>");
        }
        if (self.underlineFormat()) {
            self.message("<U>" + self.message() + "</U>");
        }
        icAgentAPI.sendChatMessage(self.selectedRoom().contactId(), self.message(), null, null);
        self.message("");
    }

    self.showMessages = function (event) {
        //check if event.chatMessages is defined
        if (event.chatMessages != undefined) {
            $.each(event.chatMessages, function () {
                var chatRoom = self.getChatRoom(event.roomId);
                self.showMessage(chatRoom, this.partyType, this.timeStamp, this.text);
            });
        }
        else {
            var chatRoom = self.getChatRoom(event.roomId);
            self.showMessage(chatRoom, event.partyType, event.timeStamp, event.message, event.label);
        }
    }

    self.showMessage = function (chatRoom, partyType, timeStamp, text, label) {
        if (chatRoom != null) {
            var localizedMessage = localizedMessages(text);
            //var message = new formattedMessage(messageEvent.partyType, messageEvent.timeStamp, unescape(localizedMessage)); // 'unescape' used to decode message
            var formattedMessage = new Message(partyType, timeStamp, localizedMessage, label);

            chatRoom.chatMessages.push(formattedMessage);
            self.updateScroll();

            if (chatRoom.roomId != self.selectedRoom().roomId && partyType == "Client") {
                chatRoom.highlightedStyle("highlightedTab");
            }
            else
                self.selectedRoom().highlightedStyle("");
        }
        else {
            throw "Invalid room Id";
        }
        if (partyType == "Agent" || partyType == "Client") {
            if (chatRoom.chatMessages().length == 1) {
                self.restartMessageTimer(chatRoom, partyType);
            }
            else if (chatRoom.chatMessages()[chatRoom.chatMessages().length - 2].partyType() != partyType) {
                self.restartMessageTimer(chatRoom, partyType);
            }
        }
    }

    self.restartMessageTimer = function (chatRoom, partyType) {

        stopTimer(chatRoom.chatMessageTimer);

        var timeMessage = chatRoom.chatMessages()[chatRoom.chatMessages().length - 1].messageTime;
        chatRoom.chatMessageTimer = startTimer(chatRoom.messageTimeElapsed, timeMessage);
        chatRoom.chatStatusType(partyType);
    }

    self.updateScroll = function () {
        var messagesPanel = document.getElementById("messagesPanel");
        messagesPanel.scrollTop = messagesPanel.scrollHeight;
    }

    self.selectRoom = function (chatRoom) {
        if (self.selectedRoom() != undefined && chatRoom.contactId() == self.selectedRoom().contactId())
            return;

        if (self.selectedRoom() != undefined) {
            //self.selectedRoom().status("Interrupted");
            self.selectedRoom().selected(false);
        }

        self.selectedRoom(chatRoom);

        if (self.selectedRoom().status() != "Disconnected" && self.selectedRoom().status() != "Active" && self.selectedRoom().status() != "Incoming") {
            icAgentAPI.activeChat(self.selectedRoom().contactId(), null, onError);
        }
        self.updateScroll();
    }

    self.getChatRoom = function (roomId) {
        var chatRoom = null;

        $.each(self.chatRooms(), function (index, item) {
            if (item.roomId() == roomId) {
                chatRoom = item;
                return;
            }

        });
        return chatRoom;
    }

    function updateContactSkill(chatRoom, skillId) {
        icAgentAPI.getSkillInfo(skillId, onGetSkillInfoSuccess, null);

        function onGetSkillInfoSuccess(skillInfo) {
            if (skillInfo.skills.Skills.length > 0) {
                chatRoom.skillName(skillInfo.skills.Skills[0].SkillName);
            }
        }
    }

    // Update Time
    self.updateElapsedTime = function (selectedElapsedTime, selectedStartTime) {
        if (self.selectedRoom() == undefined)
            return;

        if (selectedStartTime == undefined)
            return;

        var currentDate = new Date((new Date()).getTime() + self.serverTimeOffset());
        var lastDate = new Date(selectedStartTime);

        if (selectedElapsedTime == undefined)
            selectedElapsedTime = ko.observable(acme.common.getFormattedTime(currentDate - lastDate));
        else
            selectedElapsedTime(acme.common.getFormattedTime(currentDate - lastDate));
    }

    // Start Timer
    function startTimer(selectedElapsedTime, selectedStartTime) {
        var timerID = setInterval(function () { self.updateElapsedTime(selectedElapsedTime, selectedStartTime); }, 1000);
        return timerID;
    }

    //Stop Timer
    function stopTimer(selectedElapsedTimer) {
        clearInterval(selectedElapsedTimer);
    }

    function checkSkillQueue() {
        var currentDate = new Date();
        icAgentAPI.checkSkillQueue(acme.common.getFormattedDate(currentDate.toString()), onCheckSkillQueueSuccess, null);

        function onCheckSkillQueueSuccess(queueInfo) {
            self.newButtonEnabled(false);

            if (queueInfo == undefined)
                return;
            if (queueInfo.length > 0)
                self.newButtonEnabled(true);
        }
    }

    function stopCheckSkillQueueTimer() {
        clearInterval(self.skillQueueTimerId);
    }

    function startCheckSkillQueueTimer() {
        self.skillQueueTimerId = setInterval(function () { checkSkillQueue() }, 10000);
    }

    ko.bindingHandlers.selectableItem = new selectableItemHelper(self.selectRoom).SelectableItem;
}
