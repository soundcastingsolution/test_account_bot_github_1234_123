//##############################################################################
//###   l o g i n V i e w M o d e l
//##############################################################################
function loginViewModel(onGetNextEventsSuccess, onGetNextEventsError, onSystemError) {
    var self = this;
    var statusMessageTimer = null;

    self.userName = ko.observable(localStorageGet("username", ""));
    self.password = ko.observable(localStorageGet("password", ""));

    self.enableLoginBtn = ko.observable(true);
    self.loginButtonCss = ko.computed(function() {
        if (self.enableLoginBtn())
            return "buttonEnabled";
        return "buttonDisabled";
    }, this);

    self.isAuthenticated = ko.observable(false);
    self.isSessionStarted = ko.observable(false);

    self.isSessionJoined;

    self.errorMessage = ko.observable();
    self.errorMessageVisible = ko.observable(false);

    self.startSessionType = ko.observable(localStorageGet("sessionType", "PhoneNumber"));
    self.startSessionValue = ko.observable(localStorageGet("sessionValue", ""));

    this.phoneNumber = ko.computed(function () {
        if (self.startSessionType() == "PhoneNumber")
            return self.startSessionValue();

        return null;
    }, this);

    this.stationId = ko.computed(function () {
        if (self.startSessionType() == "StationId")
            return self.startSessionValue();

        return null;
    }, this);

    /// PRIVATE /////////////////////////////////////////////////
    function __validateAuthenticationFields() {
        if (self.userName() == false || self.userName() == null) {
            self.setStatusMessage("Username is required");
            return false;
        }
        else if (self.password() == false || self.password() == null) {
            self.setStatusMessage("Password is required");
            return false;
        }

        return true;
    }

    /// PRIVATE /////////////////////////////////////////////////
    function __validateStartSessionFields() {
        var value = self.startSessionValue();
        if (value == null || value == "") {
            if (self.startSessionType() == "PhoneNumber")
                self.setStatusMessage("Phone number is required.");
            else
                self.setStatusMessage("Station Id is required.");
            return false;
        }

        if (self.startSessionType() == "PhoneNumber" && (/^\+?[0-9\*\#]*$/.test(self.phoneNumber()) == false)) {
            self.setStatusMessage("Phone number is not valid.");
            return false;
        }

        return true;
    }

    /////////////////////////////////////////////////////////////
    this.authenticate = function () {
        if (localStorage["clientId"] === undefined || localStorage["clientId"] === "") {
            alert("Please set your personal settings.");
        }

        if (!__validateAuthenticationFields())
            return;

        if (!__validateStartSessionFields())
            return;

        self.isAuthenticated(false);
        self.enableLoginBtn(false);
        self.setStatusMessage("Authenticating " + self.userName() + ".  Please wait...", false);

        icAgentAPI.authenticate(self.userName(), self.password(), onAgentAuthenticated, onAgentAuthenticationError)

        function onAgentAuthenticated(data) {
            self.isAuthenticated(true);
            self.clearStatusMessage("");

            console.log("Agent Authenticated!");
            self.startSession();
        }

        function onAgentAuthenticationError(data) {
            self.setStatusMessage("Unable to authenticate " + self.userName() + ": " + data.statusDescription);
            self.enableLoginBtn(true);
        }
    }

    /////////////////////////////////////////////////////////////
    this.startSession = function () {
        self.isSessionStarted(false);
        self.setStatusMessage("Starting session for " + self.userName() + ".  Please wait...", false);

        icAgentAPI.startSession(self.phoneNumber(), self.stationId(), onSessionStarted, onStartSessionError);

        function onSessionStarted(data) {
            self.isSessionStarted(true);
            self.clearStatusMessage("");
            console.log("Session Started!");
            localStorage["sessionType"] = self.startSessionType();
            localStorage["sessionValue"] = self.startSessionValue();

            window.location.href = "../pages/Agent.html";
        }

        function onStartSessionError(data) {
            self.enableLoginBtn(true);

            if (data.statusCode == 409) {
                // A 409 in this case means that there is a session already in progress.
                obj = JSON && JSON.parse(data.responseText) || $.parseJSON(data.responseText);
                if (obj.error_description == "SessionInProgress") {
                    icAgentAPI.joinSession(onSessionJoined, onSystemError);
                }
                else {
                    self.setStatusMessage("Unable to start session for " + self.userName() + ": " + data.statusDescription + ".");
                }
            }
            else {
                self.setStatusMessage("Error starting session for " + self.userName() + ": " + data.statusCode + " " + data.statusDescription + ".");
            }
        }

        function onSessionJoined(data) {
            self.isSessionStarted(true);
            self.isSessionJoined = true;
            self.clearStatusMessage("");

            sessionStorage["isSessionJoined"] = "true";
            window.location.href = "../pages/Agent.html";
        }
    }

    /////////////////////////////////////////////////////////////
    this.endSession = function () {
        self.setStatusMessage("Ending session for " + self.userName() + ".  Please wait...", false);

        icAgentAPI.endSession(false, false, false, onSessionEnded, onEndSessionError);

        function onSessionEnded() {
            self.enableLoginBtn(true);
            self.clearStatusMessage();
            
            console.log("Session Request Success!");

            window.location.href = "../pages/Login.html";
        }

        function onEndSessionError(data) {
            if (data.statusCode == 409) {
                // A 409 in this case means that there is a contact in progress.
                self.setStatusMessage("Unable to end session for " + self.userName() + ": " + data.statusDescription + ".");
            }
            else {
                window.location.href = "../pages/Login.html";
            }
        }
    }

    /////////////////////////////////////////////////////////////
    this.setStatusMessage = function (msg, doTimeout) {
        self.errorMessage(msg);
        self.errorMessageVisible(true);

        if (statusMessageTimer != null) {
            clearTimeout(statusMessageTimer);
            statusMessageTimer = null;
        }

        if ((doTimeout === undefined || doTimeout == "undefined") || doTimeout == true) {
            statusMessageTimer = setTimeout(function () {
                self.clearStatusMessage();
                self.errorMessageVisible(false);
                statusMessageTimer = null;
            }, 5000);
        }
    }

    /////////////////////////////////////////////////////////////
    this.clearStatusMessage = function () {
        self.errorMessage("");
    }

    /////////////////////////////////////////////////////////////
    this.doReload = function (state, error) {
        var hideLoginScreen = true;
        switch (state) {
            case "attemptingToConnect":
                self.setStatusMessage("Attempting to restore session for " + self.userName() + ".  Please wait...", false);
                break;

            case "showSessionStarted":
                self.clearStatusMessage("");
                break;

            case "showLoginScreen":
                hideLoginScreen = false;
                if (error != null) {
                    self.setStatusMessage("Error restoring session for " + self.userName() + ".  " + error.statusDescription + ".");
                }
                break;
        }

        self.isSessionStarted(hideLoginScreen);
        self.isAuthenticated(hideLoginScreen);
        self.enableLoginBtn(!hideLoginScreen);
    }

    this.clear = function () {
        self.isSessionStarted(false);
        self.isAuthenticated(false);
        self.isSessionJoined = false;
    }
}
