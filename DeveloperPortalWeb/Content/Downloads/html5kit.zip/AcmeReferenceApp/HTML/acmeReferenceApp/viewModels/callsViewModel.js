﻿function contactInfo(contactId, inbound, ani, dnis, status, startDate, lastUpdateTime) {
    var self = this;

    self.contactId = ko.observable(contactId);
    self.isInbound = ko.observable(inbound);
    self.ani = ko.observable(ani);
    self.dnis = ko.observable(dnis);
    self.status = ko.observable(status);
    self.skillName = ko.observable("");
    self.startTime = ko.observable(startDate);
    self.lastUpdateTime = ko.observable(lastUpdateTime);
    self.startTimeElapsed = ko.observable("00:00");
    self.updateTimeElapsed = ko.observable("00:00");

    self.showHangupButton = ko.observable(false);
    self.showHoldButton = ko.observable(false);
    self.showResumeButton = ko.observable(false);
    
    self.fromPhoneNumber = ko.computed(function () {
        if (self.isInbound() == "True")
            return self.ani();
        else
            return self.dnis();
    }, this);
}

function skillInfo(skillId, skillName) {
    var self = this;

    self.skillId = ko.observable(skillId);
    self.skillName = ko.observable(skillName);
}

function callsViewModel(parent, onError) {
    var self = this;
    self.parent = parent;

    self.agentId = ko.observable();
    self.phoneNumber = ko.observable();
    self.agentNumber = ko.observable();
    self.skillName = ko.observable();
    self.selectedSkill = ko.observable();
    self.showTransferButton = ko.observable();
    self.conferenceCount = ko.observable();

    self.outboundSkills = ko.observableArray([]);
    self.contactList = ko.observableArray([]);

    self.timerId;
    self.agentListRefreshTimer = null;
    self.agentStatesList = ko.observableArray([]);

    self.hasContacts = ko.computed(function () {
        return (self.contactList().length > 0);
    }, this);

    self.transferCount = ko.observable(0);
    self.showTransferButton = ko.computed(function () {
        return (self.transferCount() >= 2);
    }, this);


    self.showConferenceButton = ko.computed(function () {
        return (self.conferenceCount() >= 2)
    }, this);

    self.addActiveCall = function (call) {
        var contact = new contactInfo(call.contactId, call.isInbound, call.ani, call.dnis, call.status, call.startTime, call.lastUpdateTime);
        self.contactList.push(contact);

        updateContacts();
        updateContactSkill(contact, call.skill);

        if (self.contactList().length === 1)
            startElapsedTimeTimer();
    }

    self.updateActiveCall = function (call) {
        var contact = self.getContact(call.contactId);

        if (contact != null) {
            if (call.status == "Disconnected") {
                var localizedFunction = acme.common.lookupTable[call.disconnectCode];
                if (localizedFunction != undefined)
                    contact.status(localizedFunction());
            }
            else {
                contact.lastUpdateTime(call.lastUpdateTime);
                contact.status(call.status);
            }
        }
        else if (call.status !== "Disconnected") {
            self.addActiveCall(call);
        }

        updateContacts();
    }

    self.removeActiveCall = function (call) {
        self.contactList.remove(function (item) {
            return item.contactId() == call.contactId
        });

        if (self.contactList().length === 0)
            stopElapsedTimeTimer();

        updateContacts();
    }

    /// CONTACT ////////////////////////////////////////////
    self.holdContact = function (item) {
        icAgentAPI.holdContact(item.contactId());
    }

    /// CONTACT ////////////////////////////////////////////
    self.resumeContact = function (item) {
        icAgentAPI.resumeContact(item.contactId());
    }

    /// CONTACT ////////////////////////////////////////////
    self.endContact = function (item) {
        icAgentAPI.endContact(item.contactId(), null, null);
    }

    self.dialPhone = function () {
        if (self.selectedSkill() == undefined)
            return;

        icAgentAPI.dialPhone(self.phoneNumber(), self.selectedSkill().skillName(), null, onError);
    }

    self.dialAgent = function () {
        icAgentAPI.dialAgent(self.agentNumber(), null, onError);
    }

    self.dialSkill = function () {
        icAgentAPI.dialSkill(self.skillName(), null, onError);
    }

    self.transferCalls = function () {
        icAgentAPI.transferCalls(onTransferSuccess, onTransferError);

        function onTransferSuccess() {
            self.parent.loginVM.setStatusMessage("Calls have been transferred.");
        }

        function onTransferError(data) {
            self.parent.loginVM.setStatusMessage("Error transferring calls: " + data.statusCode + " " + data.responseText);
        }
    }

    self.getContact = function (contactId) {
        var contact = null;

        $.each(self.contactList(), function (index, item) {
            if (item.contactId() == contactId)
                contact = item;
        });

        return contact;
    }

    self.loadOutboundSkills = function () {
        self.outboundSkills.removeAll();

        icAgentAPI.getAgentOutboundSkills(self.agentId(), onGetAgentOutboundSkills, onError);
    };

    function onGetAgentOutboundSkills(skills) {
        $.each(skills, function (index, item) {
            self.outboundSkills.push(new skillInfo(item.skillId, item.skillName));
        });
    }

    function updateContacts() {
        var activeCount = 0;
        // Find out how many contacts are active (not on hold, etc).
        $.each(self.contactList(), function (index, item) {
            if (item.status() == "Active")
                activeCount++;
        });


        self.conferenceCount(0);
        
        self.transferCount(0);
        $.each(self.contactList(), function (index, item) {
            var status = item.status();
            item.showHangupButton(status == "Active" || status == "Joined");
            item.showHoldButton(status == "Active");
            item.showResumeButton(status == "Holding" && activeCount == 0);
            if (status == "Active" || status == "Holding" || status == "Joined")
                self.transferCount(self.transferCount() + 1);
            if (status == "Active" || status == "Holding")
                self.conferenceCount(self.conferenceCount() + 1);

        });
    }

    function updateContactSkill(contact, skillId) {
        icAgentAPI.getSkillInfo(skillId, onGetSkillInfoSuccess, null);

        function onGetSkillInfoSuccess(skillInfo) {
            if (skillInfo.skills.length > 0) {
                contact.skillName(skillInfo.skills[0].SkillName);
            }
        }
    }

    self.transferCalls = function () {
        icAgentAPI.transferCalls(onTransferSuccess, onError);

        function onTransferSuccess() {
            self.parent.loginVM.setStatusMessage("Calls have been transferred.");
        }
    }

    self.conferenceCalls = function () {
        icAgentAPI.conferenceCalls();
    }

    function updateElapsedTime() {
        var currentDate = new Date();

        $.each(self.contactList(), function (index, item) {
            if (item.startTime() != undefined) {
                var startDate = new Date(item.startTime());
                item.startTimeElapsed(acme.common.getFormattedTime(currentDate - startDate));
            }
            if (item.lastUpdateTime() != undefined) {
                var updateDate = new Date(item.lastUpdateTime());
                item.updateTimeElapsed(acme.common.getFormattedTime(currentDate - updateDate));
            }

        });
    }

    function startElapsedTimeTimer() {
        self.timerId = setInterval(function () { updateElapsedTime() }, 1000);
    }

    function stopElapsedTimeTimer() {
        clearInterval(self.timerId);
    }

    function startAgentListRefresh() {
        if (self.agentListRefreshTimer != null)
            return;

        self.agentListRefreshTimer = setInterval(function () {
            icAgentAPI.getAgentStatesList(onRefreshSuccess, onRefreshError);
        }, 30000);

        function onRefreshSuccess(data) {
            self.agentStatesList(data);
        }

        function onRefreshError(err) {
            self.parent.loginVM.setStatusMessage("Unable to update agent states list.  Halting refresh.");
            stopAgentListRefresh();
        }
    }

    function stopAgentListRefresh() {
        clearInterval(self.agentListRefreshTimer);
        self.agentListRefreshTimer = null;
    }
}
