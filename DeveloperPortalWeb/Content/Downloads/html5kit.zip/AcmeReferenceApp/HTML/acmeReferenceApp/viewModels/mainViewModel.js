function errorModel(code, description, message) {
    var self = this;

    self.statusCode = ko.observable(code);
    self.statusDescription = ko.observable(description);
    self.message = ko.observable(message);

    this.fullError = ko.computed(function () {
        if (message != null)
            return message;

        if (this.statusCode() != null && this.statusDescription() != null)
            return "Error " + this.statusCode() + ": " + this.statusDescription();

        return "";
    }, this);
}

function mainViewModel() {
    var self = this;

    self.loginVM = new loginViewModel(onGetNextEventsSuccess, onGetNextEventsError, onSystemError);
    self.agentVM = new agentViewModel(onSystemError);
    self.callsVM = new callsViewModel(self, onSystemError);
    self.chatVM = new chatViewModel(onSystemError);
    self.viewerVM = new viewerViewModel();
    self.logVM = new logViewModel();

    self.errorMessage = ko.observable(new errorModel(null, null));

    this.StateCounterVisible = ko.computed(function () {
        return self.agentVM.isStateCounterVisible();
    }, this);

    function onGetNextEventsSuccess(events) {
        $.each(events, function (index, value) {
            var event = this;

            console.log("Processing Event: " + event.type);

            try {
                switch (event.type) {
                    case "AgentSessionStart":
                        processStartSession(event);
                        break;
                    case "AgentState":
                        processChangeState(event);
                        break;
                    case "AgentSessionEnd":
                        processEndSession(event);
                        break;
                    case "CallContactEvent":
                        processCallContact(event);
                        break;
                    case "AgentError":
                        processAgentError(event);
                        break;
                    case "AgentLeg":
                        processAgentLeg(event);
                        break;
                    case "HoursOfOperation":
                        processHoursOfOperation(event);
                        break;
                    case "ChatContactEvent":
                        processChatContact(event);
                        break;
                    case "ChatText":
                        processChatText(event);
                        break;
                }
            }
            catch (error) {
                console.log("PAGE ERROR: " + error.message);
            }
        });

        // This will keep getting events forever until the agent logs out.
        if (self.loginVM.isSessionStarted())
            icAgentAPI.nextEvents(onGetNextEventsSuccess, onGetNextEventsError);
    }

    function onGetNextEventsError(error) {
        var msg = "Unknown page error getting events."
        if (error != null) {
            if (error.statusCode == 0) {
                msg = "Connection failed. If the error continues contact your System Administrator.";
                if ($("#incomingChat").dialog("isOpen")) {
                    $("#incomingChat").dialog("close");
                    self.chatVM.incomingChatDialogVisible(false);
                }    
            }
            else
                msg = "Error getting events: " + error.statusDescription + ".  Events have been halted.";
        }
        console.log("Error: " + error.statusCode + " Desc:" + error.statusDescription + " Text: " + error.statusText + " Resp: " + error.responseText);
    }

    function onSystemError(error) {
        var msg = "Unknown page error."
        if (error != null) {
            if (error.statusCode == 0)
                msg = "Connection failed. If the error continues contact your System Administrator.";
            else
                msg = "Error " + error.statusCode + ": " + error.statusDescription;
        }

        self.loginVM.setStatusMessage(msg, true);
        console.log("Error: " + error.statusCode + " Desc:" + error.statusDescription + " Text: " + error.statusText + " Resp: " + error.responseText);
    }

    function processStartSession(event) {
        if (self.loginVM.isSessionJoined) {
            self.loginVM.setStatusMessage("You just joined an active session. Your phone number is: " + event.stationPhoneNumber, true);
        }

        self.agentVM.agentId(event.agentId);
        sessionStorage["agentId"] = event.agentId;
        self.agentVM.sessionStatus("Connected");
        self.agentVM.loadAgentInfo();
        self.agentVM.legStatusLabel("Disconnected");

        self.callsVM.agentId(event.agentId);
        self.callsVM.loadOutboundSkills();

        //Start offsetTimmer
        self.updateServerTimeOffSet(); 
       
        self.viewerVM.loadCollapsablePanels();

        self.logVM.addLog("Agent session changed: " + self.agentVM.sessionStatus());
    }

    function processEndSession(event) {
        self.loginVM.clear();
        self.agentVM.clear();
        sessionStorage.clear();
        self.logVM.addLog("Agent session changed: " + self.agentVM.sessionStatus());
        console.log("Agent session ended!");

        //Stop ServerTimeOffset timmer
        clearInterval(self.chatVM.updateServerTimeOffsetId);

        window.location.href = "../pages/Login.html";
    }

    function processChangeState(event) {
        self.agentVM.startStateTimer();
        self.agentVM.setAgentState(event.currentState, event.currentOutReason, event.startTimeUTC);
        if (event.isAcw === "True") {
            self.agentVM.isStateCounterVisible(false);
            if (event.acwTimer > 0) {
                self.agentVM.startAcwTimeout(event.acwTimer);
            }
            else {
                self.agentVM.acwtimeout("");
            }
        }
        else {
            self.agentVM.startTimeElapsed("00:00");
            self.agentVM.isStateCounterVisible(true);
        }
        sessionStorage["currentState"] = event.currentState;
        self.logVM.addLog("Agent state changed: " + self.agentVM.agentStatus());

        self.agentVM.cleanNextStates();
        if (event.nextStates.length >= 1)
            self.agentVM.setNextAgentState(event.nextStates[0].State, event.nextStates[0].OutReason);
        if (event.nextStates.length >= 2)
            self.agentVM.setNextNextAgentState(event.nextStates[1].State, event.nextStates[1].OutReason);
        
        if (self.agentVM.agentStatus() == "Refused") {
            if ($("#incomingChat").dialog("isOpen")) {
                $("#incomingChat").dialog("close");
                self.chatVM.incomingChatDialogVisible(false);
            }    
        }
    }

    function processCallContact(event) {
        if (event.status === "Dialing" || event.status === "Incoming") {
            self.callsVM.addActiveCall(event);
        }
        else if (event.status === "Active") {
            self.agentVM.loadAcwStates();
            self.callsVM.updateActiveCall(event);
        }
        else if (event.status === "Disconnected") {
            self.agentVM.unloadAcwStates();
            self.callsVM.updateActiveCall(event);
            setTimeout(function () {
                self.callsVM.removeActiveCall(event);
            }, 2000);
            
            if (event.allowDispositions === "True" && event.finalState === "False") {
                self.agentVM.showDispositions(event.skill, event.contactId);
            }
            
            if (event.allowDispositions === "True" && event.finalState === "True") {
                self.agentVM.clearDispositions();
            }
        }
        else if (event.status === "Holding") {
            self.agentVM.unloadAcwStates();
            self.callsVM.updateActiveCall(event);
        }
        else {
            self.callsVM.updateActiveCall(event);
        }
        self.logVM.addLog("New Contact State: " + event.status);
    }

    function processChatContact(event) {
        try {
            switch (event.status) {
                case "Incoming":
                    processIncomingChat(event);
                    break;
                case "Active":
                    processActiveChat(event);
                    break;
                case "Disconnected":
                    processDisconnectedChat(event);
                    break;
                case "Interrupted":
                    processInterruptedChat(event);
                    break;
            }
        }
        catch (error) {
            self.loginVM.setStatusMessage("CHAT CONTACT EVENT ERROR: " + error.message);
        }
        self.logVM.addLog("New Chat State: " + event.status);
    }

    function processChatText(event) {
        self.chatVM.showMessages(event);
    }

    function processIncomingChat(event) {

        if (self.chatVM.chatRooms().length >= 1) {
            self.chatVM.acceptChat(event);
            self.chatVM.updateChat(event);
            return;
        }

        $("#incomingChat").dialog({
            resizable: false,
            minHeight: 160,
            modal: true,
            open: function (event, ui) { $(".ui-dialog-titlebar-close").hide(); },
            buttons: {
                "Accept": function () {
                    self.chatVM.acceptChat(event);
                    self.chatVM.updateChat(event);
                    $(this).dialog("close");
                },
                "Reject": function () {
                    self.chatVM.rejectChat(event)
                    $(this).dialog("close");
                }
            }
        });
    }

    function processActiveChat(event) {
        if ($("#incomingChat").dialog("isOpen")) {
            $("#incomingChat").dialog("close");
            self.chatVM.incomingChatDialogVisible(false);
        }
        self.chatVM.updateChat(event);
        self.chatVM.activeChat(event);
    }

    function processInterruptedChat(event) {
        self.chatVM.updateChat(event);
    }

    function processDisconnectedChat(event) {
        if ($("#incomingChat").dialog("isOpen")) {
            $("#incomingChat").dialog("close");
            self.chatVM.incomingChatDialogVisible(false);
        }
        self.chatVM.disconnectChat(event);
    }

    function processAgentError(event) {
        if (event.command == "LogoffAgent") {
            self.loginVM.setStatusMessage("You cannot be logged off because you are handling one or more active contacts. Complete your contacts and the logout");
        }
        else if (event.command == "ReadyAgentLeg") {
            self.loginVM.setStatusMessage("Could not dial the Agent Leg.");
        }

        self.logVM.addLog("Agent Error!");
    }

    function processAgentLeg(event) {
        self.agentVM.legStatusLabel(event.status);
        sessionStorage["agentLegStatus"] = event.status;
    }

    function processHoursOfOperation(event) {
        console.log("ShowContinueReskill: " + event.showContinueReskill);

        if (event.showContinueReskill === "true") {
            var result = confirm("According to the hours of operation, this skill is not open. Are you sure you want to continue?");

            console.log("continueReskill: " + result);

            icAgentAPI.continueReskill(result, null, null);
        }
    }

    self.reload = function () {
        if (!icAgentAPI.tryReloadState()) {
            self.loginVM.setStatusMessage("Error loading state from localStorage.");
            setTimeout(function () { window.location.href = "../pages/Login.html"; }, 5000);
            return;
        }

        if (sessionStorageGet("isSessionJoined", "false") == "true") {
            sessionStorage["isSessionJoined"] = "false";
            self.loginVM.isSessionJoined = true;
        }

        self.loginVM.doReload("showSessionStarted");
        self.agentVM.legStatusLabel(sessionStorageGet("agentLegStatus", "Disconnected"));
        icAgentAPI.nextEvents(onGetNextEventsSuccess, onSystemError);
    };

    self.updateServerTimeOffSet = function () {
        icAgentAPI.getServerTime(onGetServerTimeSuccess);

        function onGetServerTimeSuccess(data) {

            var currentClientTime = new Date();
            
            var st = new Date(data.ServerTime);
            offSet = st.getTime() - currentClientTime.getTime();

            self.chatVM.serverTimeOffset(offSet);
            self.agentVM.serverTimeOffset(offSet);
       }
    }

    self.updateServerTimeOffsetId = setInterval(function () { self.updateServerTimeOffSet() }, 120000);
}
