function logEntry(time, message) {
    var self = this;

    self.time = ko.observable(time);
    self.message = ko.observable(message);
}

function logViewModel() {
    var self = this;

    self.messages = ko.observableArray();

    self.addLog = function (message) {
        var now = new Date();

        var newEntry = new logEntry(now.toTimeString().substring(0, 8), message);
        self.messages.unshift(newEntry);
        if (self.messages().length > 10)
            self.messages.pop();
    }
}