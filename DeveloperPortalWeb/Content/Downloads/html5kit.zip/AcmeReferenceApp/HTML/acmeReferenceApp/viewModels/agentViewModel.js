function agentState(name, outstate, description, isAcw) {
    var self = this;

    self.agentStateName = ko.observable(name);
    self.agentStateDescription = ko.observable(description);
    self.OutStateDescription = ko.observable(outstate);
    self.isAcw = ko.observable(isAcw);
}

function disposition(dispositionId, dispositionName, displayOrder) {
    var self = this;

    self.dispositionId = ko.observable(dispositionId);
    self.dispositionName = ko.observable(dispositionName);
    self.displayOrder = ko.observable(displayOrder);
}

function agentViewModel(onError) {
    var self = this;

    self.teamId = ko.observable();
    self.agentId = ko.observable();

    self.sessionStatus = ko.observable();
    self.agentStatus = ko.observable();
    self.nextAgentStatus = ko.observable();
    self.nextNextAgentStatus = ko.observable();
    self.currentAgentState = ko.observable();

    self.startDate = ko.observable();
    self.startTimeElapsed = ko.observable();
    self.legStatusLabel = ko.observable(sessionStorage["agentLegStatus"] !== undefined ? sessionStorage["agentLegStatus"] : "Disconnected");
    self.acwtimeout = ko.observable();

    self.selectedAgentState = ko.observable();
    self.agentStates = ko.observableArray([]);
    self.dispositionList = ko.observableArray([]);
    self.selectedDisposition = ko.observable();
    self.dispositionNotes = ko.observable();
    self.lastEndedContactId;
    self.agentStatesEnabled = ko.observable(true);

    self.serverTimeOffset = ko.observable(0);

    var acwTimerId;

    self.visibleAgentStates = ko.computed(function () {
        var all = self.agentStates();
        var visibleStates = [];

        for (var i = 0; i < all.length; i++) {
            if (all[i].agentStateDescription() != self.agentStatus() && all[i].agentStateDescription() != self.nextAgentStatus() && all[i].agentStateDescription() != self.nextNextAgentStatus()) {
                visibleStates.push(all[i]);
            }
        }

        return visibleStates;
    }, this);

    self.hasNextAgentStatus = ko.computed(function () {
        return (self.nextAgentStatus() !== "");
    }, this);

    self.hasNextNextAgentStatus = ko.computed(function () {
        return (self.nextNextAgentStatus() !== "");
    }, this);

    self.dispositionsVisible = ko.observable(false);

    var allUnavailableStates;

    self.elapsedTimeId;

    self.isStateCounterVisible = ko.observable(true);

    self.setAgentState = function (currentState, currentOutReason, currentStartDate) {
        var stateDescription = currentState;
        if (currentOutReason)
            stateDescription = currentOutReason;

        self.agentStatus(stateDescription);
        self.startDate(currentStartDate);

        self.updateSelectedAgentState(stateDescription);
    }

    self.setNextAgentState = function (nextState, nextOutReason) {
        var nextStateDescription = nextState;
        if (nextOutReason)
            nextStateDescription = nextOutReason;

        if (nextStateDescription == self.agentStatus() || self.agentStatus() == "PromisePending" || self.agentStatus() == "Refused") {
            self.nextAgentStatus("");
            return;
        }

        self.nextAgentStatus(nextStateDescription);

        console.log("Agent next state: " + nextStateDescription);
    }

    self.setNextNextAgentState = function (nextNextState, nextOutReason) {
        var nextStateDescription = nextNextState;
        if (nextOutReason)
            nextStateDescription = nextOutReason;

        self.nextNextAgentStatus(nextStateDescription);

        console.log("Agent next-next state: " + nextStateDescription);
    }

    self.cleanNextStates = function () {
        self.nextAgentStatus("");
        self.nextNextAgentStatus("");
    }

    self.updateSelectedAgentState = function (stateDescription) {
        var localizedFunction = acme.common.lookupTable[stateDescription];
        if (localizedFunction != undefined)
            stateDescription = localizedFunction();

        self.currentAgentState(stateDescription);

        self.selectedAgentState(null);

        console.log("New selected state: " + stateDescription);
    }

    function loadDefaultStates() {
        self.agentStates.removeAll();
        self.agentStates.push(new agentState("Available", "", "Available", false));
        self.agentStates.push(new agentState("Unavailable", "", "Unavailable", false));
    }

    function loadUnavailableStates(acw) {
        if (self.allUnavailableStates === undefined)
            return;

        $.each(self.allUnavailableStates, function () {
            if (this.IsActive === true) {
                if (this.IsAcw === acw) {
                    self.agentStates.push(new agentState("Unavailable", this.OutStateDescription.trim(), this.OutStateDescription.trim(), acw));
                }
            }
        });

        self.updateSelectedAgentState(self.agentStatus());
    }

    self.loadAgentInfo = function () {
        loadDefaultStates();

        icAgentAPI.getAgentInfo(self.agentId(), onGetAgentInfo, onError);
    }

    self.loadUnavailableCodes = function () {
        icAgentAPI.getUnavailableCodes(self.teamId(), onGetUnavailableCodes, onError);
    }

    self.agentStateChanged = function () {
        if (self.selectedAgentState() != undefined)
            icAgentAPI.setAgentState(self.selectedAgentState().agentStateName(), self.selectedAgentState().OutStateDescription(), null, onError);
    }

    function onGetAgentInfo(data) {
        self.teamId(data.teamId);

        console.log("Loading agent info for agent: " + self.agentId())

        self.loadUnavailableCodes(self.teamId(), onGetUnavailableCodes, onError);
    }

    function onGetUnavailableCodes(unavailableCodes) {
        console.log("Loading unavailable codes for team: " + self.teamId())
        self.allUnavailableStates = unavailableCodes;
        loadUnavailableStates(false);
    }

    self.loadAcwStates = function () {
        loadUnavailableStates(true);
    }

    self.unloadAcwStates = function () {
        self.agentStates(self.agentStates.remove(function (item) {
            return item.isAcw() !== true
        }));
    }

    self.dialEndAgentLeg = function () {
        if (self.legStatusLabel() === "Disconnected") {
            icAgentAPI.dialAgentLeg(onAgentLegDialed, onError);
        } else if (self.legStatusLabel() === "Active") {
            icAgentAPI.endAgentLeg(onAgentLegEnded, onError);
        }

        function onAgentLegDialed(event) {
            self.legStatusLabel(event.status);
        }

        function onAgentLegEnded(event) {
            self.legStatusLabel(event.status);
        }
    }

    self.legStatusIcon = ko.computed(function () {
        if (self.legStatusLabel() === "Disconnected") {
            return "../images/icon_leg_disconnected.png";
        } else if (self.legStatusLabel() === "Dialing") {
            return "../images/icon_leg_dialing.png";
        } else {
            return "../images/icon_leg_connected.png";
        }
    }, this);

    self.showDispositions = function (skillId, contactId) {
        icAgentAPI.getSkillInfo(skillId, onGetSkillInfoSuccess, onError);
        self.lastEndedContactId = contactId;
        var skillName;

        function onGetSkillInfoSuccess(skillReturned) {
            var skill = new Skill();
            skill.ParseFromJson(skillReturned.skills[0]);
            if (skill.useDisposition === true || skill.requireDisposition === true) {
                icAgentAPI.getDispositionList(skill.skillName, onGetDispositionListSuccess, onError);
                if (skill.requireDisposition === true)
                    self.agentStatesEnabled(false);
            }
        }

        function onGetDispositionListSuccess(dispositionList) {
            var dispositions = new SkillDispositions();
            dispositions.ParseFromJson(dispositionList.SkillDispositions);
            self.dispositionsVisible(true);
            $.each(dispositions.dispositionCodes, function () {
                self.dispositionList.push(new disposition(this.dispositionId, this.dispositionName, this.displayOrder));
            });
        }
    }

    self.setDisposition = function () {
        if (self.selectedDisposition() != undefined) {
            self.dispositionNotes(self.dispositionNotes() === undefined ? "" : self.dispositionNotes());
            icAgentAPI.setDisposition(self.selectedDisposition().dispositionName(), self.dispositionNotes(), self.lastEndedContactId, onSetDispositionSuccess, onError);
        }

        function onSetDispositionSuccess(data) {
            self.agentStatesEnabled(true);
            clearInterval(acwTimerId);
        }
    }

    self.startAcwTimeout = function (timeout) {
        self.acwtimeout(acme.common.getFormattedTime(timeout * 1000));
        var intervalTimeout = 1000;
        acwTimerId = setInterval(function () {
            if (timeout > 0) {
                timeout = timeout - 1;
                self.acwtimeout(acme.common.getFormattedTime(timeout * 1000));
            } else {
                clearInterval(intervalId);
                self.acwtimeout("");
            }
        }, intervalTimeout);
    }

    this.clear = function () {
        self.sessionStatus("Disconnected");
        self.legStatusLabel("Disconnected");
        self.startTimeElapsed("00:00");
        self.stopStateTimer();
    }

    self.startStateTimer = function () {
        self.startDate(new Date());
        self.elapsedTimeId = setInterval(function () { self.updateElapsedTime() }, 1000);
    }

    self.stopStateTimer = function () {
        clearInterval(self.elapsedTimeId);
    }

    self.updateElapsedTime = function () {
        if (self.startDate() == undefined)
            return;
     
        var currentDate = new Date((new Date()).getTime() + self.serverTimeOffset());
        var lastDate = new Date(self.startDate());

        self.startTimeElapsed(acme.common.getFormattedTime(currentDate - lastDate));
    }

    self.clearDispositions = function () {
        self.dispositionList.removeAll();
        self.dispositionsVisible(false);
    }
}
