﻿function collapsablePanel(name, isVisible, icon, tooltipMessage) {
    var self = this;

    self.panelName = ko.observable(name);
    self.isPanelVisible = ko.observable(isVisible);
    self.panelIcon = ko.observable(icon);
    self.tooltipMessage = ko.observable(tooltipMessage);
}

function viewerViewModel() {
    var self = this;

    self.collapsablePanels = ko.observableArray([]);

    self.isPanelVisible = function (panelName) {
        return ko.computed({
            read: function () {
                var isVisible = false;
                $.each(self.collapsablePanels(), function (index, item) {
                    if (item.panelName() == panelName)
                        isVisible = item.isPanelVisible();
                });
                return isVisible;
            },
            write: function (checked) {
            }
        }, this);
    }; 

    self.loadCollapsablePanels = function () {
        self.collapsablePanels.removeAll();
        self.collapsablePanels.push(new collapsablePanel("eventsPanel", true, "../images/icon_panel_logs.png", "Show/Hide logs panel"));
        self.collapsablePanels.push(new collapsablePanel("phonePanel", false, "../images/icon_panel_phone.png", "Show/Hide outbound panel"));
        self.collapsablePanels.push(new collapsablePanel("dialAgentPanel", false, "../images/icon_agent.png", "Show/Hide dial agent panel"));
        self.collapsablePanels.push(new collapsablePanel("dialSkillPanel", false, "../images/icon_skill.png", "Show/Hide dial skill panel"));
    }

    self.changeVisibility = function (item) {
        item.isPanelVisible(!item.isPanelVisible());
    }
}