acme.common.settingsViewModel = (function settingsViewModel() {
    this.tokenServiceUri = ko.observable();
    this.clientId = ko.observable();
    this.clientSecret = ko.observable();
    this.scope = ko.observable();

    var auth = icAgentAPI.getAuthContext();
    __update();

    /// PRIVATE /////////////////////////////////////////////////
    function __update() {
        this.tokenServiceUri(auth.tokenServiceUri);
        this.clientId(auth.clientId);
        this.clientSecret(auth.clientSecret);
        this.scope(auth.scope);
    }

    /////////////////////////////////////////////////////////////
    this.saveSettings = function () {
        auth.tokenServiceUri = this.tokenServiceUri();
        auth.clientId = this.clientId();
        auth.clientSecret = this.clientSecret();
        auth.scope = this.scope();
        auth.saveSettings();

        document.location.href = '../pages/Login.html';
    };

    /////////////////////////////////////////////////////////////
    this.clearSettings = function () {
        auth.clearSettings();
        __update();
    }
})();