﻿
Partial Class scripts_libs_json2
    Inherits System.Web.UI.Page

End Class
