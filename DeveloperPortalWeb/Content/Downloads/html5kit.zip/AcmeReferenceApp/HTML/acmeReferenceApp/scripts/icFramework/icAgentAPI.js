// Create a faux console, if one does not exist (compatibility for older browsers)
// IE9 doesn't have a console unless you hit F12.
if (!(window.console && console.log)) {
    console = {
        log: function () { },
        debug: function () { },
        info: function () { },
        warn: function () { },
        error: function () { }
    };
}

//##############################################################################
//###   i c A g e n t A P I
//##############################################################################

/*
This library wraps all rest calls for the Agent Api
*/
var icAgentAPI = (function () {
    // force cross-site scripting (as of jQuery 1.5)
    jQuery.support.cors = true;

    var _auth = new ResourceOwnerPasswordAuthorizer();
    var _firstSessionId = sessionStorageGet("firstSessionId", "");
    var _sessionId = sessionStorageGet("sessionId", "");
    var _agentId = null;
    var _longPoolTimeout = 15;

    var _phoneNumber = null;
    var _stationId = null;

    /// PRIVATE ////////////////////////////////////////////
    //  Keep the session ID updated, and persisted to sessionStorage.
    function __updateSessionId(newSessionId, updateFirstSessionId) {
        if (updateFirstSessionId) {
            _firstSessionId = newSessionId;
            sessionStorage["firstSessionId"] = newSessionId;
        }

        _sessionId = newSessionId;
        sessionStorage["sessionId"] = newSessionId;
    }


    ////// INTERNAL ////////////////////////////////////////
    this.requestAuthenticate = function (userName, password, onSuccess, onError) {
        _auth.authenticate(userName, password, onSuccess, onError);
    };


    ////// INTERNAL ////////////////////////////////////////
    // Start Session
    //
    // POST: .../services/v2.0/agent-sessions
    //
    // Parameters (start with phone number):
    //     {
    //         stationPhoneNumber: <phone number>
    //     }
    //
    // Parameters (start with station ID):
    //     {
    //         stationPhoneNumber: <phone number>
    //     }
    //
    // Return JSON:
    //     {
    //         sessionId: <session ID>
    //     }
    //
    this.requestStartSession = function (phoneNumber, stationId, onSuccess, onError) {
        var relativeUri;

        if (phoneNumber != null) {
            relativeUri = "services/v2.0/agent-sessions?stationPhoneNumber=" + encodeURIComponent(phoneNumber);
        } else if (stationId != null) {
            relativeUri = "services/v2.0/agent-sessions?stationId=" + encodeURIComponent(stationId);
        }
        else {
            console.log("You should select one of Phone Number or StationId");
        }

        _auth.sendRequest("POST", relativeUri, "", onStartSessionSuccess, onError);

        function onStartSessionSuccess(data) {
            _phoneNumber = phoneNumber;
            sessionStorage["phoneNumber"] = phoneNumber;

            _stationId = stationId;
            sessionStorage["stationId"] = stationId;

            __updateSessionId(data.sessionId, true);

            console.log("Session Id Saved!");

            if (onSuccess != null)
                onSuccess();
        };
    };


    ////// INTERNAL ////////////////////////////////////////
    // Join Session
    //
    // POST: .../InContactAPI/services/v2.0/agent-sessions/join
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {
    //         sessionId: <session ID>
    //     }
    //
    this.requestJoinSession = function (onSuccess, onError) {
        var relativeUri = "services/v2.0/agent-sessions/join";

        _auth.sendRequest("POST", relativeUri, "", onJoinSessionSuccess, onJoinSessionError);

        function onJoinSessionSuccess(data) {
            __updateSessionId(data.sessionId, true);

            if (onSuccess != null)
                onSuccess();
        }

        function onJoinSessionError(error) {
            console.log("Join session failed for user.  " + error.statusCode + " " + error.statusDescription);
            __updateSessionId(null, true);

            if (onError != null)
                onError(error);
        }
    };


    ////// INTERNAL ////////////////////////////////////////
    // End Session
    //
    // DELETE: .../services/v2.0/agent-sessions/{sessionId}
    //
    // Parameters:
    //     {
    //         forceLogout: <true/false>,
    //         endContacts: <true/false>,
    //         ignorePersonalQueue: <true/false>
    //     }
    //
    // Return JSON:
    //     {}
    //
    this.requestEndSession = function (forceLogout, endContacts, ignorePersonalQueue, onSuccess, onError) {
        if (forceLogout === null || forceLogout === undefined) {
            forceLogout = true;
        }
        if (endContacts === null || endContacts === undefined) {
            endContacts = true;
        }
        if (ignorePersonalQueue === null || ignorePersonalQueue === undefined) {
            ignorePersonalQueue = true;
        }

        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "?forceLogout=" + encodeURIComponent(forceLogout) + "&endContacts=" + encodeURIComponent(endContacts) + "&ignorePersonalQueue=" + encodeURIComponent(ignorePersonalQueue);

        _auth.sendRequest("DELETE", relativeUri, "", onEndSessionSuccess, onError);

        function onEndSessionSuccess(data) {
            __updateSessionId(null, true);

            if (onSuccess != null)
                onSuccess();
        }
    };

    ////// INTERNAL ////////////////////////////////////////
    // Request Events
    //
    // GET: .../services/v2.0/agent-sessions/{sessionId}/get-next-event
    //
    // Parameters:
    //     {
    //         timeout: <0-60>
    //     }
    //
    // Return JSON:
    //     {
    //         sessionId: <updated-session-id>,
    //         events: [ <array-of-events> ]
    //     }
    //
    // Remarks:
    //     The session ID contains a timestamp that is used to keep track of
    //     which events your client knows about.  When you start a session,
    //     you will get a session with the time-stamp set to zero.  You can
    //     use that session ID when you need to re-query all events, like when
    //     the user refreshes the page.
    //    
    //     Each time you call get-next-event, you will get an updated session
    //     ID.  Always use this new ID to get the most recent events.
    //
    //     The system does not keep events in a queue.  Events are posted to 
    //     slots, where old events replace a newer events of the same type.
    //
    this.requestNextEvents = function (onSuccess, onError) {
        console.log("Requesting next events!");

        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/get-next-event?timeout=" + encodeURIComponent(_longPoolTimeout);

        _auth.sendRequest("GET", relativeUri, "", onGetEventsSuccess, onGetEventsError);

        function onGetEventsSuccess(data, statusText) {
            var events = [];

            console.log("Event: " + JSON.stringify(data));

            if (statusText == "Session Ended") {
                __updateSessionId(null, true);

                var agentSessionEndEvent = new AgentSessionEndEvent();
                agentSessionEndEvent.type = "AgentSessionEnd";
                events.push(agentSessionEndEvent);

                console.log("Aditional Control for Session Ended Event");
            }
            else if (data !== undefined && data.events !== undefined) {
                __updateSessionId(data.sessionId, false);

                $.each(data.events, function () {
                    switch (this.Type) {
                        case "AgentLeg":
                            var agentLegEvent = new AgentLegEvent();
                            agentLegEvent.ParseFromJson(this);
                            events.push(agentLegEvent);
                            break;
                        case "AgentState":
                            var agentStateEvent = new AgentStateEvent();
                            agentStateEvent.ParseFromJson(this);
                            events.push(agentStateEvent);
                            break;
                        case "AgentSessionStart":
                            var agentSessionStartEvent = new AgentSessionStartEvent();
                            _agentId = agentSessionStartEvent.agentId;
                            agentSessionStartEvent.ParseFromJson(this);
                            events.push(agentSessionStartEvent);
                            break;
                        case "AgentSessionEnd":
                            var agentSessionEndEvent = new AgentSessionEndEvent();
                            agentSessionEndEvent.ParseFromJson(this);
                            events.push(agentSessionEndEvent);
                            break;
                        case "CallContactEvent":
                            var callContactEvent = new CallContactEvent();
                            callContactEvent.ParseFromJson(this);
                            events.push(callContactEvent);
                            break;
                        case "AgentError":
                            var agentErrorEvent = new AgentErrorEvent();
                            agentErrorEvent.ParseFromJson(this);
                            events.push(agentErrorEvent);
                            break;
                        case "HoursOfOperation":
                            var hoursOperation = new HoursOfOperationEvent();
                            hoursOperation.ParseFromJson(this);
                            events.push(hoursOperation);
                            break;
                        case "ChatContactEvent":
                            var chatContactEvent = new ChatContactEvent();
                            chatContactEvent.ParseFromJson(this);
                            events.push(chatContactEvent);
                            break;
                        case "ChatText":
                            var chatTextEvent = new ChatTextEvent();
                            chatTextEvent.ParseFromJson(this);
                            events.push(chatTextEvent);
                            break;
                        default:
                            console.log("Event " + this.Type + " cannot be handled")
                    }
                });
            }

            onSuccess(events);
        };

        function onGetEventsError(error) {
            if (error == null)
                console.log("Unknown error getting next events.  Event polling has halted.");
            else
                console.log("getEvents error.  statusCode=" + error.statusCode + "  description=" + error.statusDescription);

            if (onError != null)
                onError(error);
        };
    }

    ////// INTERNAL ////////////////////////////////////////
    // Set Agent State
    //
    // POST .../services/v2.0/agent-sessions/{sessionId}/state
    //
    // Parameters:
    //     {
    //         state: <"available" or "unavailable">,
    //         reason: <optional-unavailable-code>
    //     }
    //
    // Return JSON:
    //     {}
    //
    this.requestSetAgentState = function (state, outstateReason, onSuccess, onError) {
        if (!state) {
            onError({ "statusCode": "400", "statusDescription": "Must supply the state to set the agent on" });
            return;
        }

        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/state?state=" + encodeURIComponent(state);

        if (state == "Unavailable" && outstateReason) {
            relativeUri = relativeUri + "&" + "reason=" + encodeURIComponent(outstateReason);
        }

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Get Team Unavailble Codes
    //
    // GET: .../services/v2.0/admin/teams/{teamId}/unavailable-codes
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {
    //         "unavailableList": [ <JSON-array> ]
    //     }
    //
    this.requestTeamUnavailableCodes = function (teamId, onSuccess, onError) {
        var relativeUri = "services/v2.0/admin/teams/" + encodeURIComponent(teamId) + "/unavailable-codes";

        _auth.sendRequest("GET", relativeUri, "", onRequestTeamUnavailableCodesSuccess, onRequestTeamUnavailableCodesError);

        function onRequestTeamUnavailableCodesSuccess(data) {
            onSuccess(data.unavailableList);
        };

        function onRequestTeamUnavailableCodesError(error) {
            onError();
        };
    }

    ////// INTERNAL ////////////////////////////////////////
    // Get Agent Info
    //
    // GET .../services/v1.0/agents/{agentId}
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {
    //         "agents": [ <JSON-array> ]
    //     }
    // 
    // Remarks:
    //     The agent ID is optional.  If you omit it from the URI, then the 
    //     system will return info for all agents.
    //
    this.requestAgentInfo = function (agentId, onSuccess, onError) {
        var relativeUri = "services/v1.0/agents/" + encodeURIComponent(agentId);

        _auth.sendRequest("GET", relativeUri, "", onRequestAgentInfoSuccess, onRequestAgentInfoError);

        function onRequestAgentInfoSuccess(data) {
            var agentInfo = new AgentInfo();
            agentInfo.ParseFromJson(data.agents[0]);
            onSuccess(agentInfo);
        };

        function onRequestAgentInfoError(error) {
            onError();
        };
    }

    ////// INTERNAL ////////////////////////////////////////
    // Get Agent's Outbound Skills
    //
    //     (see requestAgentSkills, and requestAgentSkillAssignments)
    //
    this.requestAgentOutboundSkills = function (agentId, onSuccess, onError) {
        requestAgentSkills(onGetAgentSkills, onError);

        var outboundSkills = [];
        var assignedOutboundSkills = [];

        function onGetAgentSkills(skills) {
            $.each(skills, function (index, item) {
                if (item.isOutbound === true && item.isActive === true) {
                    outboundSkills.push(item);
                }
            });

            requestAgentSkillAssignments(onGetAgentSkillAssignments, onError);
        };

        function onGetAgentSkillAssignments(skillAssignments) {
            $.each(skillAssignments, function (index, item) {
                if (agentId == item.agentId && isOutboundSkill(item) === true)
                    assignedOutboundSkills.push(item);
            });

            onSuccess(assignedOutboundSkills);
        };

        function isOutboundSkill(skill) {
            var founded = false;

            $.each(outboundSkills, function (index, item) {
                if (item.skillId == skill.skillId)
                    founded = true;
            });

            return founded;
        }
    }

    ////// INTERNAL ////////////////////////////////////////
    // Get Skills
    //
    // GET: .../services/v1.0/skills/{skillId}
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {
    //         "skills": [ <JSON-array> ]
    //     }
    //
    // Remarks
    //     The skill ID in the URI is optional.  If it is omitted, then the
    //     system will return all skills in the business unit.
    //
    this.requestAgentSkills = function (onSuccess, onError) {
        var relativeUri = "services/v2.0/skills";

        _auth.sendRequest("GET", relativeUri, "", onRequestAgentSkillsSuccess, onError);

        function onRequestAgentSkillsSuccess(data) {
            var skills = [];

            $.each(data.skills.Skills, function (index, value) {
                var skill = new Skill();
                skill.ParseFromJson(this);
                skills.push(skill);
            });

            onSuccess(skills);
        };
    }

    ////// INTERNAL ////////////////////////////////////////
    // Get Agent Skill Assignments
    //
    // GET: .../services/v1.0/agents/skills
    //
    // Parameters:
    //     (none)
    // 
    // Return JSON:
    //     {
    //         "agentSkillAssignments": [ <JSON-array> ]
    //     }
    //
    this.requestAgentSkillAssignments = function (onSuccess, onError) {
        var relativeUri = "services/v1.0/agents/skills";

        _auth.sendRequest("GET", relativeUri, "", onRequestAgentSkillsSuccess, onError);

        function onRequestAgentSkillsSuccess(data) {
            var skillAssignments = [];

            $.each(data.agentSkillAssignments, function (index, value) {
                var skillAssignment = new AgentSkillAssignments();
                skillAssignment.ParseFromJson(this);
                skillAssignments.push(skillAssignment);
            });

            onSuccess(skillAssignments);
        };
    }

    ////// INTERNAL ////////////////////////////////////////
    // Get Agent Skills
    //
    // GET: .../services/v1.0/agents/{agentId}/skills
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {
    //         "AgentSkillAssignments": [ <JSON-array> ]
    //     }
    //
    this.requestAgentSkillList = function (agentId, onSuccess, onError) {
        var relativeUri = "services/v1.0/agents/" + encodeURIComponent(agentId) + "/skills";

        _auth.sendRequest("GET", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Hang Up Call
    //
    // POST: .../services/v2.0/agent-sessions/{sessionId}/interactions/{contactId}/end
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {}
    //
    this.requestEndContact = function (contactId, onSuccess, onError) {
        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/interactions/" + encodeURIComponent(contactId) + "/end";

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Hold Call
    //
    // POST: .../services/v2.0/agent-sessions/{sessionId}/interactions/{contactId}/hold
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {}
    //
    this.requestHoldContact = function (contactId, onSuccess, onError) {
        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/interactions/" + encodeURIComponent(contactId) + "/hold";

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Resume Call
    //
    // POST: .../services/v2.0/agent-sessions/{sessionId}/interactions/{contactId}/hold
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {}
    //
    this.requestResumeContact = function (contactId, onSuccess, onError) {
        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/interactions/" + encodeURIComponent(contactId) + "/resume";

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Dial the Agent Leg
    //
    // POST: .../services/v2.0/agent-sessions/{sessionId}/agent-phone/dial
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {}
    //
    this.requestDialAgentLeg = function (onSuccess, onError) {
        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/agent-phone/dial";

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Hang Up the Agent Leg
    //
    // POST: .../services/v2.0/agent-sessions/{sessionId}/agent-phone/end
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {}
    //
    this.requestEndAgentLeg = function (onSuccess, onError) {
        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/agent-phone/end";

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Dial an Outbound Call
    //
    // POST: .../services/v2.0/agent-sessions/{sessionId}/dial-phone
    //
    // Parameters:
    //     {
    //         phoneNumber: <phone-number>,
    //         skillName: <skill-name>
    //     }
    //
    // Return JSON:
    //     {}
    //
    this.requestDialPhone = function (phoneNumber, skillName, onSuccess, onError) {
        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/dial-phone?phoneNumber=" + encodeURIComponent(phoneNumber) + "&skillName=" + encodeURIComponent(skillName);

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Dial a Skill
    //
    // POST: .../services/v2.0/agent-sessions/{sessionId}/dial-skill
    //
    // Parameters:
    //     {
    //         skillName: <skill-name>
    //     }
    //
    // Return JSON:
    //     {}
    //
    this.requestDialSkill = function (skillName, onSuccess, onError) {
        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/dial-skill?skillName=" + encodeURIComponent(skillName);

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Dial a Skill
    //
    // POST: .../services/v2.0/agent-sessions/{sessionId}/dial-agent
    //
    // Parameters:
    //     {
    //         agentUsername: <agent-username>
    //     }
    //
    // Return JSON:
    //     {}
    //
    this.requestDialAgent = function (agentUsername, onSuccess, onError) {
        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/dial-agent?agentUsername=" + encodeURIComponent(agentUsername);

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Continue Re-skill
    //
    // POST: .../services/v2.0/agent-sessions/{sessionId}/continue-reskill
    //
    // Parameters:
    //     {
    //         continueReskill: <"true" or "false">
    //     }
    //
    // Return JSON:
    //     {}
    //
    this.requestContinueReskill = function (continueReskill, onSuccess, onError) {
        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/continue-reskill?continueReskill=" + encodeURIComponent(continueReskill);

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Transfer Calls
    //
    // POST: .../services/v2.0/agent-sessions/{sessionId}/interactions/transfer-calls
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {}
    //
    this.requestTransferCalls = function (onSuccess, onError) {
        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/interactions/transfer-calls";

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Get All Skills
    //
    // GET: .../services/v1.0/skills
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {
    //         "skills": [ <JSON-array> ]
    //     }
    //
    this.requestSkillInfo = function (skillId, onSuccess, onError) {
        var relativeUri = "services/v1.0/skills/" + encodeURIComponent(skillId);

        _auth.sendRequest("GET", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Get All Dispositions for a Skill
    //
    // GET: .../services/v1.0/skills/{skillName}/dispositions
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {
    //         "dispositions": [ <JSON-array> ]
    //     }
    //
    this.requestDispositionsList = function (skillName, onSuccess, onError) {
        var relativeUri = "services/v2.0/skills/" + encodeURIComponent(skillName) + "/dispositions";

        _auth.sendRequest("GET", relativeUri, "", onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Set Disposition
    //
    // PUT: .../services/v2.0/agent-sessions/{_sessionId}/interactions/{contactId}/disposition
    //
    // Parameters:
    //     {
    //         dispositionName: <disposition-name>, 
    //         dispositionNotes: <disposition-notes>
    //     }
    //
    this.requestSetDisposition = function (dispositionName, dispositionNotes, contactId, onSuccess, onError) {
        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/interactions/" + encodeURIComponent(contactId) + "/disposition";
        var parameters = { "dispositionName": dispositionName, "dispositionNotes": dispositionNotes };
        _auth.sendRequest("PUT", relativeUri, parameters, onSuccess, onError);
    }

    ////// INTERNAL ////////////////////////////////////////
    // Conference Calls
    //
    // POST: .../services/v2.0/agent-sessions/{sessionId}/interactions/conference-calls
    //
    // Parameters:
    //     (none)
    //
    // Return JSON:
    //     {}
    //
    this.requestConferenceCalls = function (onSuccess, onError) {
        var relativeUri = "services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/interactions/conference-calls";

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }


    // Chat

    this.requestAcceptChat = function (contactId, onSuccess, onError) {
        var relativeUri = "/services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/interactions/" + encodeURIComponent(contactId) + "/accept";

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    this.requestRejectChat = function (contactId, onSuccess, onError) {
        var relativeUri = "/services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/interactions/" + encodeURIComponent(contactId) + "/reject";

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    this.requestEndChat = function (contactId, onSuccess, onError) {
        var relativeUri = "/services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/interactions/" + encodeURIComponent(contactId) + "/end";

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    this.requestSendChatMessage = function (contactId, message, onSuccess, onError) {
        var relativeUri = "/services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/interactions/" + encodeURIComponent(contactId) + "/send-chat-text";
        //var parameters = { "ChatText": escape(message) }; //'scape' used to encode message
        var parameters = { "ChatText": message };

        _auth.sendRequest("POST", relativeUri, parameters, onSuccess, onError);
    }

    this.requestActiveChat = function (contactId, onSuccess, onError) {
        var relativeUri = "/services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/interactions/" + encodeURIComponent(contactId) + "/activate-chat";

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    this.requestAddChat = function (onSuccess, onError) {
        var relativeUri = "/services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/interactions/add-chat";

        _auth.sendRequest("POST", relativeUri, "", onSuccess, onError);
    }

    this.requestTransferChat = function (contactId, targetSkillName, onSuccess, onError) {
        var relativeUri = "/services/v2.0/agent-sessions/" + encodeURIComponent(_sessionId) + "/interactions/" + encodeURIComponent(contactId) + "/transfer-chat";
        var parameters = { "targetSkillName": targetSkillName };
        _auth.sendRequest("POST", relativeUri, parameters, onSuccess, onError);
    }

    this.requestSkillQueue = function (updatedSince, onSuccess, onError) {
        var relativeUri = "/services/v2.0/cache/skillqueue";
        var parameters = { "fields": "", "updatedSince": updatedSince };

        _auth.sendRequest("GET", relativeUri, parameters, onRequestSkillQueueSuccess, onError);

        function onRequestSkillQueueSuccess(data) {
            var skillsQueue = [];

            if (data.resultSet.SkillQueue != undefined) {
                $.each(data.resultSet.SkillQueue, function (index, value) {
                    var skillQueue = new SkillQueue();
                    skillQueue.ParseFromJson(this);
                    skillsQueue.push(skillQueue);
                });

                onSuccess(skillsQueue);
            }
            else
                onSuccess(undefined);
        };
    }

    return {
        ////////////////////////////////////////////////////
        // authenticate
        //     Call this method to authenticate the user against the inContact
        //     platform.
        //
        // Parameters:
        //     userName: Agent's username.
        //     password: Agent's password.
        //     onSuccess: A function that will be called when the user has been 
        //         successfully authenticated.  The function will be passed an 
        //         AuthenticationContext object.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     There is no logout method.  Authentication lasts until 20 minutes 
        //     after the last icAgentAPI method is called.  
        //
        //     Beginning an agent session requires two steps.  You must first 
        //     authenticate against the inContact platform.  If this function 
        //     completes successfully, then you must start a session by calling
        //     the startSession() method.
        //
        // Return Status Codes:
        //     See the ResourceOwnerPasswordAuthorizer.authenticate() method.
        //
        authenticate: function (userName, password, onSuccess, onError) {
            requestAuthenticate(userName, password, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // conferenceCalls
        //     Connects two or more calls together in a conference.
        //
        // Parameters:
        //     onSuccess: A function that will be called when the request has
        //         been completed.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     To create a conference, you have to have at least two calls.  
        //     They can be either active or on hold.
        //
        // Return Status Codes:
        //     202 Accepted.  (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid agent session.
        //     409 InvalidState: Can't create a conference at this time.
        //
        conferenceCalls: function (onSuccess, onError) {
            requestConferenceCalls(onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // continueReskill
        //     Continue or cancel a reskill call during closed hours.
        //
        // Parameters:
        //     continueReskill: true or false.
        //     onSuccess: A function that will be called when the request has
        //         been completed.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     If you transfer a call to a skill, and the hours of operation 
        //     for that skill indicate that business is closed, you will get
        //     a response back asking for confirmation.
        //
        //     Call this method, and set continueReskill to true if you really
        //     want to sent the customer to that skill queue (this would be 
        //     useful in situations where the customer could leave a voicemail).
        //
        //     If you set continueReskill to false, then the transfer will be
        //     aborted.
        //
        // Return Status Codes:
        //     202 Accepted.  (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid agent session.
        //
        continueReskill: function (continueReskill, onSuccess, onError) {
            requestContinueReskill(continueReskill, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // dialAgent
        //     Dials another agent.
        //
        // Parameters:
        //     agentUsername: Name of the agent you want to dial.
        //     onSuccess: A function that will be called when the request has
        //         been completed.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     Call this method when you want to transfer a contact to an agent.
        //
        //     This function will place a call to an agent's personal queue.
        //
        //     If the agent has an active contact, then this function will fail
        //     with a 409 InvalidState.  The agent must put all contacts on 
        //     hold.
        //
        // Return Status Codes:
        //     202 Accepted.  (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     400 InvalidAgentUsername: The agent username you gave was 
        //         invalid.
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid agent session.
        //     403 MultiConferenceNotEnabled: This agent is not allowed to 
        //         conference more than two calls.
        //     409 InvalidState: Can't dial out at this time.
        //
        dialAgent: function (agentUsername, onSuccess, onError) {
            requestDialAgent(agentUsername, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // dialAgentLeg
        //     Dials the agent leg.
        //
        // Parameters:
        //     onSuccess: A function that will be called when the request has
        //         been completed.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     Call this function to dial the agent leg.  If the agent does 
        //     not receive any calls in 30 seconds, the agent leg will hang up.
        //
        //     You can configure this value by modifying the timeout on the
        //     station profile in Central.
        //
        // Return Status Codes:
        //     202 Accepted.  (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid agent session.
        //     409 InvalidState: Can't dial the agent leg at this time.
        // 
        dialAgentLeg: function (onSuccess, onError) {
            requestDialAgentLeg(onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // dialPhone
        //     Places an outbound call.
        //
        // Parameters:
        //     phoneNumber: The phone number to dial.
        //     skillName: The name of an outbound skill to use.
        //     onSuccess: A function that will be called when the request has
        //         been completed.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     You must call icAgentAPI.startSession() before using this 
        //     method.
        //
        //     When placing a call, you must select a skill so that the system
        //     knows how to classify the call.
        //
        //     After placing the request, you can track the status of the call
        //     by calling icAgentAPI.nextEvents().  You will get a series of 
        //     CallContactEvents.  The first one will indicate that the call is
        //     dialing.  Then you will receive one telling you whether or not
        //     the call connected, busy, or failed to connect.
        //
        //     The system will only allow the digits 0-9, *, #, and +.  Anything
        //     else will give you a 400 InvalidPhoneNumber.
        //   
        //     You must put all active contacts on hold before calling this 
        //     method.  If you try to place a call when you have any active 
        //     contacts, you will get back a 409 InvalidState.  
        //
        // Return Status Codes:
        //     202 Accepted.  (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     400 InvalidPhoneNumber: Invalid phone number.  The system found
        //         illegal characters in the phone number.
        //     400 InvalidSkill: The skill given was not valid for the user.
        //     401 InvalidSecurityUser: Unauthorized.
        //     403 MultiConferenceNotEnabled: This agent is not allowed to 
        //         conference more than two calls.
        //     404 InvalidAgentSession: Invalid agent session.
        //     409 InvalidState: You can't place a call at this time.
        // 
        dialPhone: function (phoneNumber, skillName, onSuccess, onError) {
            requestDialPhone(phoneNumber, skillName, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // dialSkill
        //     Dials a skill queue.
        //
        // Parameters:
        //     skillName: Name of the skill you want to dial.
        //     onSuccess: A function that will be called when the request has
        //         been completed.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //     
        // Remarks:
        //     Call this method when you want to transfer a contact to another
        //     skill; for instance, if a customer calls in to sales and the
        //     agent wants to route them to tech support.
        //
        //     If the hours of operation for the target skill are closed, you 
        //     can call continueReskill to force the transfer.
        //
        // Return Status Codes:
        //     202 Accepted.  (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid agent session.
        //     400 InvalidSkill: The skill given was not valid for the user.
        //     409 InvalidState: You can't place a call at this time.
        //     403 MultiConferenceNotEnabled: This agent is not allowed to 
        //         conference more than two calls.
        // 
        dialSkill: function (skillName, onSuccess, onError) {
            requestDialSkill(skillName, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // endAgentLeg
        //     Hangs up the agent leg.
        //
        // Parameters:
        //     onSuccess: A function that will be called when the request has
        //         been completed.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     Use this method to hang up the agent leg.  The agent leg will
        //     hang up automatically if the agent is longer than 30 seconds (or
        //     whatever the timeout for the agent's station profile is set to).
        //
        // Return Status Codes:
        //     202 Accepted.  (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid agent session.
        //     409 InvalidState: Can't dial the agent leg at this time.
        // 
        endAgentLeg: function (onSuccess, onError) {
            requestEndAgentLeg(onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // endContact
        //     Hangs up a call.
        //
        // Parameters:
        //     contactId: The contactId for the call that you wish to terminate.
        //     onSuccess: A function that will be called when the contact has 
        //         been ended.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //     
        // Remarks:
        //     You can get the contactId by keeping track of events (by calling
        //     icAgentAPI.nextEvents()).  Look for a CallContactEvent.
        //
        //     If you try to end a call while it's on hold, you'll get a 409 
        //     InvalidState.
        //
        // Return Status Codes:
        //     202 Success: (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid agent session.
        //     404 InvalidContactId: Invalid contact ID.
        //     409 InvalidState: Cannot end the contact at this time.
        // 
        endContact: function (contactId, onSuccess, onError) {
            requestEndContact(contactId, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // endSession
        //     Ends the agent's session.
        //
        // Parameters:
        //     forceEnd:
        //         Forces a session end.  Make sure you set ignorePersonalQueue 
        //         to how you want contacts in the personal queue to be handled.
        //     endContacts:
        //         This tells the system to kill (hang up, or otherwise 
        //         terminate) all contacts that are assigned to the agent.  The 
        //         personal queue is not affected.
        //     ignorePersonalQueue:
        //         If this value is true, then the contacts remain in the 
        //         personal queue indefinitely.  Patrons will hear hold music
        //         with an occaisional message asking if they'd like to be
        //         transferred back to the skill queue.
        //     onSuccess: A function that will be called if this method 
        //         succeeds.  This function does not take any parameters.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     This table describes what happens if the agent HAS ONE OR MORE
        //     contacts, based on the values of forceLogout and endContact.
        //
        //     Force  End
        //     End:   Contacts:  Notes:
        //     =========================================================================================
        //     false  (ignored)  Session-end will fail.  This method will return a 409 AgentStillHasContacts.
        //     true   false      Session-end will succeed, but the agent will remain connected
        //                       to all contacts.
        //     true   true       Session-end will succeed, and all the agent's contacts will 
        //                       be forcibly terminated.
        //
        //     The following table describes what happens if the agent HAS ONE
        //     OR MORE contacts in their personal queue.
        //
        //     Force  Ignore  
        //     End:   Prs Q:     Notes
        //     =========================================================================================
        //     false  false      Session-end will fial.  The method will return a 409 PersonalQueueNotEmpty.
        //     true   false      All contacts in the personal queue are re-queued based on
        //                       the contact's skill.
        //     N/A    true       All contacts in the personal queue remain until the agent
        //                       logs in again.
        // 
        // Return Status Codes:
        //     202 Accepted: Success.
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid agent session.
        //     409 AgentStillHasContacts: Agent must handle all contacts before ending the session.
        //     409 PersonalQueueNotEmpty: Personal queue must be empty before ending the session.
        //
        endSession: function (forceEnd, endContacts, ignorePersonalQueue, onSuccess, onError) {
            requestEndSession(forceEnd, endContacts, ignorePersonalQueue, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // getAgentId
        //     Gets the agentId for the user that is currently authenticated.
        //
        // Remarks:
        //     This function will throw an exception unless you have started or
        //     joined the session, and queried for events.
        //
        getAgentId: function () {
            if (_agentId == null)
                throw "Must call icAgentAPI.nextEvents(), before accesing this property.";

            return _agentId;
        },


        ////////////////////////////////////////////////////
        // getAgentInfo
        //     Gets an AgentInfo object for the requested agent.
        //
        // Parameters:
        //     agentId: Id of the agent that you want info for.  Use 
        //         icAgentAPI.getAgentId() to get the agentId for the agent 
        //         currently logged in.
        //     onSuccess: A function that will be called when the request 
        //         completes. The function will be passed an AgentInfo object.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //     
        // Return Status Codes:
        //     200 OK
        //     404 InvalidAgentId: Invalid agentId.
        //     401 InvalidSecurityUser: Unauthorized.
        getAgentInfo: function (agentId, onSuccess, onError) {
            requestAgentInfo(agentId, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // getAgentOutboundSkills
        //     Gets a list of outbound skills for the agent.
        //
        // Parameters:
        //     agentId: Id of the agent that you want info for.  Use 
        //         icAgentAPI.getAgentId() to get the agentId for the agent 
        //         currently logged in.
        //     onSuccess: A function that will be called when the request 
        //         completes. The function will be passed an array of Skill 
        //         objects.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //     
        // Return Status Codes (varies):
        //     200 OK
        //     404 InvalidAgentId: Invalid agentId.
        //     401 InvalidSecurityUser: Unauthorized.
        //
        getAgentOutboundSkills: function (agentId, onSuccess, onError) {
            requestAgentOutboundSkills(agentId, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // getAgentSkillList
        //     Gets all skills assigned to this agent.
        //
        // Remarks:
        //     agentId: Id of the agent that you want info for.  Use 
        //         icAgentAPI.getAgentId() to get the agentId for the agent 
        //         currently logged in.
        //     onSuccess: A function that will be called when the request 
        //         completes. The function will be passed an array of Skill 
        //         objects.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //     
        // Return Status Codes (varies):
        //     200 OK
        //     404 InvalidAgentId: Invalid agentId.
        //     401 InvalidSecurityUser: Unauthorized.
        // 
        getAgentSkillList: function (agentId, onSuccess, onError) {
            requestAgentSkillList(agentId, onSuccess, onError);
        },

        getSkillList: function (onSuccess, onError) {
            requestAgentSkills(onSuccess, onError);
        },

        ////////////////////////////////////////////////////
        // getAuthContext
        //     This method returns the ResourceOwnerPasswordAuthorizer used by
        //     the icAgentAPI instance.
        //
        // Parameters:
        //     (none)
        //
        getAuthContext: function () {
            return _auth;
        },


        ////////////////////////////////////////////////////
        // getDispositionList
        //     Gets a list of dispositions for a skill, if the skill has
        //     dispositions associated with it.
        //
        // Parameters:
        //     skillName: Name of a skill.
        //     onSuccess: A function that will be called when the request 
        //         completes. The function will be passed an array of 
        //         dispositions.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Return Status Codes:
        //     200 OK.
        //     400 InvalidSkill: Invalid skill name.
        //     401 InvalidSecurityUser: Unauthorized.
        // 
        getDispositionList: function (skillName, onSuccess, onError) {
            requestDispositionsList(skillName, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // getSkillInfo
        //     Gets info for a specific skill.
        //
        // Parameters:
        //     skillId: ID for a skill.
        //     onSuccess: A function that will be called when the request 
        //         completes. The function will be passed an array of Skill 
        //         objects.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     Use this method to get info about a skill.
        //
        // Return Status Codes:
        //     200 OK.
        //     400 InvalidSkillId: Invalid skill ID.
        //     401 InvalidSecurityUser: Unauthorized.
        // 
        getSkillInfo: function (skillId, onSuccess, onError) {
            requestSkillInfo(skillId, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // getUnavailableCodes
        //     Gets all unavailable codes that the agent can use.
        //
        // Parameters:
        //     teamId: The team ID for the agent's team.  
        //     onSuccess: A function that will be called when the request 
        //         completes. The function will be passed an array of 
        //         unavailable codes.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     To get the team ID, you will have to jump through a few hoops.
        //     After starting your session, call icAgentAPI.nextEvents().  After
        //     that, you can get the agentId by calling icAgentAPI.getAgentId().
        //     Next, call icAgentAPI.getAgentInfo(), and this will contain a 
        //     property for the agent's teamId.
        //
        //     The set of unavailable codes can change throughout the day, as
        //     managers re-assign agents to different skills.  Your client app
        //     should call this method once every few minutes, if you want the
        //     list to stay up to date.
        //
        // Return Status Codes:
        //     200 OK.
        //     400 InvalidTeamId: Invalid team ID.
        //     401 InvalidSecurityUser: Unauthorized.
        //
        getUnavailableCodes: function (teamId, onSuccess, onError) {
            requestTeamUnavailableCodes(teamId, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // holdContact
        //     Puts a call on hold.
        //
        // Parameters
        //     contactId: The contactId for the call that you wish to put on 
        //         hold.
        //     onSuccess: A function that will be called when the contact has 
        //         been put on hold.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //     
        // Remarks:
        //     You can get the contactId by keeping track of events (by calling
        //     icAgentAPI.nextEvents()).  Look for a CallContactEvent.
        //
        //     If you try to put a call on hold while it's already on hold, 
        //     you'll get a 409 InvalidState.
        //
        // Return Status Codes:
        //     202 Success: (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid agent session.
        //     404 InvalidContactId: Invalid contact ID.
        //     409 InvalidState: Cannot put the contact on hold at this time.
        // 
        holdContact: function (contactId, onSuccess, onError) {
            requestHoldContact(contactId, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // isSessionStarted
        //     Tells whether or not an agent session is active.
        //
        isSessionStarted: function () {
            return (_sessionId != null);
        },


        ////////////////////////////////////////////////////
        // joinSession
        //     Joins an existing session.  Call this method if 
        //     icAgentAPI.startSession returns a 409 SessionInProgress.
        //
        // Parameters:
        //     onSuccess: A function that will be called when the user has 
        //         successfully joined the session.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     After onSuccess is called, you must call icAgentAPI.nextEvents() 
        //     to get the latest events.  
        //
        // Return Status Codes:
        //     202 Accepted.  (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     400 InvalidSession: Invalid session.
        //     401 InvalidSecurityUser: Unauthorized.
        //
        joinSession: function (onSuccess, onError) {
            requestJoinSession(onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // nextEvents
        //     Gets the most recent events for the current session.
        //
        // Parameters:
        //     onSuccess: A function that will be called when there are events.
        //         The function will be passed an array of event objects.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     onSuccess will be called if there are any events.  If there are
        //     no events, then the request will return after 15 seconds with a
        //     304 No Events.
        //
        // Return Status Codes:
        //     200 OK
        //     200 EventMissed: Your session ID is out of date.  Use the new
        //         session ID from this response, and call nextEvents again.
        //     200 SessionEnded: Your session has ended.  All further requests
        //         will fail.
        //     304 No Events
        //     400 InvalidTimeout: Invalid Timout. Value must be between 0-60.
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid session ID.
        //     
        nextEvents: function (onSuccess, onError) {
            requestNextEvents(onSuccess, onError)
        },


        ////////////////////////////////////////////////////
        // resumeContact
        //     Takes a call off hold.
        //
        // Parameters
        //     contactId: The contactId for the call that you wish to take off
        //         hold.
        //     onSuccess: A function that will be called when the contact has 
        //         been taken off hold.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //     
        // Remarks:
        //     You can get the contactId by keeping track of events (by calling
        //     icAgentAPI.nextEvents()).  Look for a CallContactEvent.
        //
        //     If you try to take an active call off hold, you'll get a 409 
        //     InvalidState.
        //
        // Return Status Codes:
        //     202 Success: (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid agent session.
        //     404 InvalidContactId: Invalid contact ID.
        //     409 InvalidState: Cannot take the contact off hold at this time.
        // 
        resumeContact: function (contactId, onSuccess, onError) {
            requestResumeContact(contactId, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // setAgentState
        //     Sets the agent's state.
        //
        // Parameters:
        //     state: This can be either "Available" or "Unavailable".  If the
        //         state is "Unavailable", then you can optionally set the
        //         unavailable code.
        //     unavailableCode: The name of an unavailable code (ignored if 
        //         state is "Available").  
        //     onSuccess: A function that will be called when there the request
        //         completes.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     You can call icAgentAPI.getUnavailableCodes() to get the list of
        //     valid unavailable codes for this agent.
        //
        //     You can get a 409 InvalidState if the agent tries to select an 
        //     ACW unavailable code when they're not on a contact.  You can't 
        //     set your unavailable reason to an ACW state unless you are on a 
        //     contact.
        //
        // Return Status Codes:
        //     202 Success: (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     400 InvalidAgentState: Invalid state request.  Use "Available" or 
        //         "Unavailable".
        //     400 InvalidUnavailableCode: The unavailble code you specified is
        //         not valid for this agent.
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid session ID.
        //     409 InvalidState: The requested state-change cannot be handled at
        //         this time.
        // 
        setAgentState: function (state, unavailableCode, onSuccess, onError) {
            requestSetAgentState(state, unavailableCode, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // setDisposition
        //     Sets a disposition for a contact.
        //
        // Parameters:
        //     dispositionName: Disposition name.  Call getDispositionList to 
        //         get a list of valid dispositions for this skill.
        //     dispositionNotes: Notes that the agent wants to enter.
        //     contactId: Contact ID for the call.
        //     onSuccess: A function that will be called when there the request
        //         completes.
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        // Remarks:
        //     Use this method to set dispositions during ACW, once a contact
        //     has ended.
        //
        // Return Status Codes:
        //     202 Success: (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     400 InvalidDisposition: Invalid disposition name.
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid session ID.
        //     404 InvalidContactId: Invalid contact ID.
        //
        setDisposition: function (dispositionName, dispositionNotes, contactId, onSuccess, onError) {
            requestSetDisposition(dispositionName, dispositionNotes, contactId, onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // startSession
        //     Begins an agent session.  Once the session has been started, the 
        //     agent can set their state and take calls.
        //
        // Parameters:
        //     phoneNumber: Phone number for the agent.  If this parameter has
        //         a value, then stationId will be ignored.
        //     stationId: Station number.  This parameter is only used if the
        //         phoneNumber parameter is null or empty.
        //     onSuccess: A function that will be called when the user has been 
        //         successfully authenticated.  
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     After onSuccess is called, you must call icAgentAPI.nextEvents() 
        //     to get the latest events.  
        //
        //     If you get a 409 SessionInProgress error, then you must call 
        //     icAgentAPI.joinSession().
        //
        // Return Status Codes:
        //     202 Accepted.  (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     400 PhoneNumberOrStationInUse: Phone number or station ID is in 
        //         use.
        //     400 InvalidPhoneNumberOrStation: Invalid Station or Phone Number.
        //     400 AgentOrStationLimitExceeded: Concurrent agent limit or 
        //         station limit exceeded.
        //     401 InvalidSecurityUser: Unauthorized.
        //     409 SessionInProgress: Cannot start a session at this time.  
        //         Agent session already started.
        //     
        startSession: function (phoneNumber, stationId, onSuccess, onError) {
            requestStartSession(phoneNumber, stationId, onSuccess, onError);
        },

        ////////////////////////////////////////////////////
        // transferCalls
        //     Transfers two or more calls, and returns the agent to Available.
        //
        // Parameters:
        //     onSuccess: A function that will be called when the request has 
        //         been successfully sent.  
        //     onError: A function that will be called if there are any errors.
        //         This function will be passed an icApiError object.
        //
        // Remarks:
        //     There are many scenarios where you can transfer calls:
        //     1.  You have two or more calls that are active or on hold, and 
        //         you want to connect them to each other and go back to 
        //         available.
        //     2.  You are on a conference, and you want to leave the conference
        //         and go available again.
        //     3.  You have dialed an agent, or a skill, and you want to 
        //         transfer the call to the agent/skill, then go available 
        //         again.
        //
        // Return Status Codes:
        //     202 Accepted.  (call icAgentAPI.nextEvents() to get the latest 
        //         events).
        //     401 InvalidSecurityUser: Unauthorized.
        //     404 InvalidAgentSession: Invalid session ID.
        //     409 InvalidState: Can't do a transfer at this time.
        // 
        transferCalls: function (onSuccess, onError) {
            requestTransferCalls(onSuccess, onError);
        },


        ////////////////////////////////////////////////////
        // tryReloadState
        //     Call this method to re-load the agent's state from sessionStorage
        //     and localStorage.
        //
        // Remarks:
        //     Call this method when a page first loads.  If this method returns
        //     true, then the user has already logged in.  If this method 
        //     returns false, then the page should redirect the user to a login
        //     screen.
        //
        //     There are two situations that your web application will have to 
        //     manage:
        //     1.  The user has logged in on one page, and is being redirected 
        //         to another page.
        //     2.  The user has hit F5 and refreshed the page.
        //
        //     The icAgentAPI object caches authentication and session info in 
        //     localStorage.  When you call this method, the object will try and
        //     re-load its state.  If it succeeds, then it will return a true.
        //
        //     When the agent ends the session, all session info in localStorage
        //     is cleared.
        //
        //     The authentication token is also kept in localStorage, but it has
        //     a lifetime of 20 minutes.
        //
        // Return Values:
        //     true: Agent state has been successfully re-loaded.
        //     false: Agent state was not found.  The agent should retry logging
        //         in.
        tryReloadState: function () {
            if (!_auth.tryReloadState())
                return false;

            _sessionId = _firstSessionId;
            return _sessionId != "";
        },

        // Chat Stuff
        acceptChat: function (contactId, onSuccess, onError) {
            requestAcceptChat(contactId, onSuccess, onError);
        },

        rejectChat: function (contactId, onSuccess, onError) {
            requestRejectChat(contactId, onSuccess, onError);
        },

        endChat: function (contactId, onSuccess, onError) {
            requestEndChat(contactId, onSuccess, onError);
        },

        sendChatMessage: function (contactId, message, onSuccess, onError) {
            requestSendChatMessage(contactId, message, onSuccess, onError);
        },

        activeChat: function (contactId, onSuccess, onError) {
            requestActiveChat(contactId, onSuccess, onError);
        },

        addChat: function (onSuccess, onError) {
            requestAddChat(onSuccess, onError);
        },

        transferChat: function (contactId, targetSkillName, onSuccess, onError) {
            requestTransferChat(contactId, targetSkillName, onSuccess, onError);
        },

        checkSkillQueue: function (updatedSince, onSuccess, onError) {
            requestSkillQueue(updatedSince, onSuccess, onError);
        }
    }
})();


//##############################################################################
//###   A u t h e n t i c a t i o n C o n t e x t
//##############################################################################
function AuthenticationContext() {
    this.accessToken = "";
    this.expiresIn = "";
    this.refreshToken = "";
    this.scope = "";
    this.resourceServerBaseUri = "";
    this.refreshTokenServerUri = "";
    this.tokenType = "";

    /////////////////////////////////////////////////////////////
    this.parseFromJson = function (data) {
        this.accessToken = data.access_token;
        this.expiresIn = data.expires_in;
        this.refreshToken = data.refresh_token;
        this.scope = data.scope;
        this.resourceServerBaseUri = data.resource_server_base_uri;
        this.refreshTokenServerUri = data.refresh_token_server_uri;
        this.tokenType = data.token_type;
    }

    ////// INTERNAL ////////////////////////////////////////
    this.tryReloadState = function () {
        var text = sessionStorageGet("auth", "");

        try {
            var obj = JSON.parse(text);

            this.accessToken = obj.accessToken;
            this.expiresIn = obj.expiresIn;
            this.refreshToken = obj.refreshToken;
            this.scope = obj.scope;
            this.resourceServerBaseUri = obj.resourceServerBaseUri;
            this.refreshTokenServerUri = obj.refreshTokenServerUri;
            this.tokenType = obj.tokenType;
            //////////////////////////////////////////////////////////////////////////////////////////////
        }
        catch (error) {
            console.log("Unable to parse AuthenticationContext from sessionStorage: " + error);
            return false;
        }

        return true;
    }

    ////// INTERNAL ////////////////////////////////////////
    this.saveSettings = function () {
        var text = JSON.stringify(this);
        sessionStorage["auth"] = text;
    }
}


//##############################################################################
//###   R e s o u r c e O w n e r P a s s w o r d A u t h o r i z e r
//##############################################################################
function ResourceOwnerPasswordAuthorizer() {
    var self = this;
    this.authContext = null;
    this.tokenServiceUri = "";
    this.clientId = "";
    this.clientSecret = "";
    this.scope = "";

    var _username = "";
    var _password = "";

    /// PRIVATE /////////////////////////////////////////////////
    function sendRequestRaw(httpMethod, uri, headers, parameters, onSuccess, onError) {
        if ($.browser.msie && $.browser.version < 10 && window.XDomainRequest) {
            try {
                // Pack all custom args/headers into the query string
                uri += (uri.indexOf("?") < 0)? "?": "&";
                uri += "iecors=true";
                uri += "&Authorization=" + encodeURIComponent(headers.Authorization);
                httpMethod = httpMethod.toLowerCase();
                if (httpMethod == "put") {
                    httpMethod = "post";
                    uri += "&httpMethod=put";
                }
                else if (httpMethod == "delete") {
                    httpMethod = "post";
                    uri += "&httpMethod=delete";
                }

                // Content body must be a string
                if (!(typeof(parameters) === 'string'))
                    parameters = JSON.stringify(parameters);

                // Use Microsoft XDR
                var xdr = new XDomainRequest();
                xdr.onload = function () {
                    var response = JSON.parse(xdr.responseText);
                    if (response.status_code && response.status_code >= 300) {
                        var err = new icApiError(response.status_code, "Error", "Error sending request", response.status_description);
                        if (onError != null)
                            onError(err);
                    }
                    else if (response.ieCorsResult && response.ieCorsResult.statusCode >= 300) {
                        var err = new icApiError(response.ieCorsResult.statusCode, "Error", "Error sending request", response.ieCorsResult.statusDescription);
                        if (onError != null)
                            onError(err);
                    }
                    else {
                        if (onSuccess != null)
                            onSuccess(response, "Ok");
                    }
                };

                xdr.onerror = function () {
                    var err = new icApiError("5??", "Unknown error", "XDomainRequest error", "XDomainRequest error");
                    if (onError != null)
                        onError(err);
                }

                xdr.ontimeout = function () {
                    var err = new icApiError("5??", "Request Timeout", "The XDomainRequest request timed out.", "");
                    if (onError != null)
                        onError(err);
                }

                xdr.timeout = 60000;
                xdr.onprogress = function () { };
                xdr.open(httpMethod, uri);
                xdr.send(parameters);
            }
            catch (error) {
                console.log("Error sending request via XDomainRequest: " + error);
                var err = new icApiError("5??", "Unknown error", "Error in icAgentAPI sending XDomainRequest request: " + error, "XDomainRequest error");
                if (onError != null)
                    onError(err);
            }
            return;
        }
        else {
            $.ajax({
                type: httpMethod,
                dataType: 'Json',
                crossDomain: true,
                url: uri,
                data: parameters,
                beforeSend: function (request) {
                    $.each(headers, function (key, value) {
                        request.setRequestHeader(key, value);
                    })
                },
                success: function (data, status, XHR) {
                    if (onSuccess != null)
                        onSuccess(data, XHR.statusText);
                },
                error: function (XHR, status, error) {
                    var err = new icApiError(XHR.status, XHR.statusText, error, XHR.responseText);
                    if (onError != null)
                        onError(err);
                }
            });
        }
    }

    ///// INTERNAL //////////////////////////////////////////////
    this.saveSettings = function () {
        localStorage["tokenServiceUri"] = this.tokenServiceUri;
        localStorage["clientId"] = this.clientId;
        localStorage["clientSecret"] = this.clientSecret;
        localStorage["scope"] = this.scope;
    };

    ///// INTERNAL //////////////////////////////////////////////
    this.loadSettings = function () {
        this.tokenServiceUri = localStorageGet("tokenServiceUri", "");
        this.clientId = localStorageGet("clientId", "");
        this.clientSecret = localStorageGet("clientSecret", "");
        this.scope = localStorageGet("scope", "");
    };


    ///// INTERNAL //////////////////////////////////////////////
    this.tryReloadState = function () {
        _username = localStorage["username"];
        if (_username == null)
            return false;

        _password = localStorage["password"];
        if (_password == null)
            return false;

        self.authContext = new AuthenticationContext();
        return (self.authContext.tryReloadState());
    }

    /////////////////////////////////////////////////////////////
    // clearSettings
    //     Clears all internal parameters being kept in 
    //     localStorage.  Do not call this method while the user
    //     is currently logged in.
    //
    this.clearSettings = function () {
        localStorageClear("tokenServiceUri");
        localStorageClear("clientId");
        localStorageClear("clientSecret");
        localStorageClear("scope");
        this.loadSettings();
    };


    /////////////////////////////////////////////////////////////
    // isAuthenticated
    //     Used to determine whether the user for this 
    //     ResourceOwnerPasswordAuthorizer has successfully been
    //     authenticated or not.
    //
    this.isAuthenticated = function () {
        return (self.authContext != null);
    }


    /////////////////////////////////////////////////////////////
    // authenticate
    //     Authenticates a user with the inContact platform.
    //
    // Parameters:
    //     username: inContact username.
    //     password: User's password.
    //     onSuccess: A function that will be called when the user has been 
    //         successfully authenticated.  The function will be passed an 
    //         AuthenticationContext object.
    //     onError: A function that will be called if there are any errors.
    //         This function will be passed an icApiError object.
    //
    // Return Status Codes:
    //     200 Suceess.
    //     400 Auth_UnsupportedGrantType: Unsupported grant type.
    //     400 Auth_BadPassword: Password cannot be blank.
    //     400 Auth_OAuthBadRequest: (OAuth error.  See message body for more information.)
    //     400 Auth_UnkownClientRequestError: Unknown client request.
    //     401 Auth_InvalidClientRequest: Badly-formed authentication request.
    //     401 Auth_AccessDenied: Invalid username or password.
    //     401 Auth_OAuthAccessDenied: (OAuth error.  See message body for more information.)
    //     401 Auth_AccessDenied: (See message body for more information.)
    //
    this.authenticate = function (username, password, onSuccess, onError) {
        console.log("Authenticating user " + username + " against " + self.tokenServiceUri);

        self.authContext = null;

        var token64 = $.base64.encode(self.clientId + ":" + self.clientSecret);
        var headers = { "Authorization": "Basic " + token64, "Content-Type": "application/x-www-form-urlencoded; charset=utf-8" }
        var parameters = { "grant_type": "password", "username": username, "password": password, "scope": self.scope };

        sendRequestRaw("POST", self.tokenServiceUri, headers, parameters, onAuthenticateSuccess, onAuthenticateError);

        function onAuthenticateSuccess(data, text) {
            console.log("User " + username + " has been authenticated against " + self.tokenServiceUri);

            _username = username;
            localStorage["username"] = username;
            _password = password;
            localStorage["password"] = password;

            self.authContext = new AuthenticationContext();
            self.authContext.parseFromJson(data);
            self.authContext.saveSettings();

            if (onSuccess != null)
                onSuccess(self.authContext);
        }

        function onAuthenticateError(errData) {
            console.log("Authentication failed for user " + username + " against " + self.tokenServiceUri);

            if (onError != null)
                onError(errData);
        }
    };


    /////////////////////////////////////////////////////////////
    // sendRequest
    //     Utility method for making REST calls into the inContact platform.
    //
    // Parameters:
    //     httpMethod: One of the following values: "GET", "POST", "PUT", or 
    //         "DELETE".
    //     relativeUri: Relative URI for the request.  The URI does not need to
    //         start with a leading slash.
    //     parameters: A JSON object containing any parameters you want included
    //         in the message body.
    //     onSuccess: A function that will be called if the REST request returns
    //         a 2xx status code.  The function will get two parameters.  The
    //         first is an object containing the data from the response body.  
    //         The second parameter is a string containing the response's status 
    //         text.
    //     onError: A function that will be called if there are any errors.
    //         This function will be passed an icApiError object.
    //
    this.sendRequest = function (httpMethod, relativeUri, parameters, onSuccess, onError) {
        var requestHeaders = { "Authorization": "Bearer " + self.authContext.accessToken, "Content-Type": "application/x-www-form-urlencoded; charset=utf-8" };
        var fullUri = self.authContext.resourceServerBaseUri + relativeUri;

        sendRequestRaw(
            httpMethod,
            fullUri,
            requestHeaders,
            parameters,
            onSuccess,
            onSendRequestRawError);

        function onSendRequestRawError(error) {
            if (error.statusCode == 401 && error.statusDescription == "Unauthorized" && self.tryReloadState()) {
                self.authenticate(_username, _password, onRetrySuccess, onError);
                return;
            }

            if (onError != null)
                onError(error);
        }

        function onRetrySuccess() {
            sendRequestRaw(
                httpMethod,
                fullUri,
                requestHeaders,
                parameters,
                onSuccess,
                onError);
        }
    }

    this.loadSettings();
};


//##############################################################################
//###   i c A p i E r r o r
//##############################################################################
function icApiError(statusCode, statusText, statusDescription, responseText) {
    this.statusCode = statusCode;
    this.statusText = statusText;
    this.statusDescription = statusDescription;
    this.responseText = responseText;
}


//##############################################################################
//###   A g e n t L e g E v e n t
//##############################################################################
function AgentLegEvent() {
    this.type = "";
    this.agentLegId = "";
    this.status = "";
    this.isFinalState = "";

    /////////////////////////////////////////////////////////////
    this.ParseFromJson = function (json) {
        this.type = json.Type;
        this.agentLegId = json.AgentLegId;
        this.status = json.Status;
        this.isFinalState = json.FinalState;
    }
}


//##############################################################################
//###   A g e n t S t a t e E v e n t
//##############################################################################
function AgentStateEvent() {
    this.type = "";
    this.currentState = "";
    this.currentOutReason = "";
    this.startTimeUTC = "";
    this.isAcw = "";
    this.acwTimer = "";
    this.nextStates = "";

    /////////////////////////////////////////////////////////////
    this.ParseFromJson = function (json) {
        this.type = json.Type;
        this.currentState = json.CurrentState;
        this.currentOutReason = json.CurrentOutReason;
        this.startTimeUTC = json.StartTimeUTC;
        this.isAcw = json.IsAcw;
        this.acwTimer = json.AcwTimer;
        this.nextStates = json.NextStates;
    }
}


//##############################################################################
//###   A g e n t S e s s i o n S t a r t E v e n t
//##############################################################################
function AgentSessionStartEvent() {
    this.type = "";
    this.busNo = "";
    this.agentId = "";
    this.contactId = "";
    this.stationPhoneNumber = "";
    this.stationCallerId = "";
    this.dialerCampaign = "";
    this.dialerCampaignStartTime = "";
    this.supervisorPermissionLevel = "";
    this.canMask = "";
    this.agentSchedulePermission = "";
    this.scoreRecordingsPermission = "";
    this.hideAgentStatePermission = "";

    /////////////////////////////////////////////////////////////
    this.ParseFromJson = function (json) {
        this.type = json.Type;
        this.busNo = json.BusNo;
        this.agentId = json.AgentId;
        this.contactId = json.SessionId;
        this.stationPhoneNumber = json.StationPhoneNumber;
        this.stationCallerId = json.StationCallerId;
        this.dialerCampaign = json.DialerCampaign;
        this.dialerCampaignStartTime = json.DialerCampaignStartTime;
        this.supervisorPermissionLevel = json.SupervisorPermissionLevel;
        this.canMask = json.CanMask;
        this.agentSchedulePermission = json.AgentSchedulePermission;
        this.scoreRecordingsPermission = json.ScoreRecordingsPermission;
        this.hideAgentStatePermission = json.HideAgentStatePermission;
    }
}


//##############################################################################
//###   A g e n t S e s s i o n E n d E v e n t
//##############################################################################
function AgentSessionEndEvent() {
    this.type = "";

    /////////////////////////////////////////////////////////////
    this.ParseFromJson = function (json) {
        this.type = json.Type;
    }
}


//##############################################################################
//###   C a l l C o n t a c t E v e n t
//##############################################################################
function CallContactEvent() {
    this.type = "";
    this.contactId = "";
    this.status = "";
    this.originalState = "";
    this.callType = "";
    this.dnis = "";
    this.ani = "";
    this.skill = "";
    this.isInbound = "";
    this.startTime = "";
    this.lastUpdateTime = "";
    this.screenPopUrl = "";
    this.disconnectCode = "";
    this.isLogging = "";
    this.timeout = "";
    this.allowDispositions = "";
    this.label = "";
    this.isLinked = "";
    this.timeZones = "";
    this.finalState = "";

    /////////////////////////////////////////////////////////////
    this.ParseFromJson = function (json) {
        this.type = json.Type;
        this.contactId = json.ContactID;
        this.status = json.Status;
        this.originalState = json.OriginalState;
        this.callType = json.CallType;
        this.dnis = json.DNIS;
        this.ani = json.ANI;
        this.skill = json.Skill;
        this.isInbound = json.IsInbound;
        this.startTime = json.StartTimeUTC;
        this.lastUpdateTime = json.LastStateChangeTimeUTC;
        this.screenPopUrl = json.ScreenPopUrl;
        this.disconnectCode = json.DisconnectCode;
        this.isLogging = json.IsLogging;
        this.timeout = json.Timeout;
        this.allowDispositions = json.AllowDispositions;
        this.label = json.Label;
        this.isLinked = json.IsLinked;
        this.timeZones = json.TimeZones;
        this.finalState = json.FinalState;
    }
}


//##############################################################################
//###   C h a t C o n t a c t E v e n t
//##############################################################################
function ChatContactEvent() {
    var self = this;

    self.type = "";
    self.contactID = "";
    self.roomId = '';
    self.status = "";
    self.skill = "";
    self.startTime = "";
    self.lastStateChangeTime = "";
    self.screenPopUrl = "";
    self.refusalTimeout = "";
    self.isActive = "";
    self.finalState = "";
    self.chatMessages = new Array();

    /////////////////////////////////////////////////////////////
    self.ParseFromJson = function (json) {
        self.type = json.Type;
        self.contactID = json.ContactID;
        self.roomId = json.RoomId;
        self.status = json.Status;
        self.skill = json.Skill;
        self.startTime = json.StartTime;
        self.lastStateChangeTime = json.LastStateChangeTime;
        self.screenPopUrl = json.ScreenPopUrl;
        self.refusalTimeout = json.RefusalTimeout;
        self.isActive = json.IsActive;
        self.finalState = json.FinalState;
        if (json.Messages != undefined) {
            $.each(json.Messages, function () {
                var chatMessage = new ChatMessage();
                chatMessage.ParseFromJson(this);
                self.chatMessages[self.chatMessages.length] = chatMessage;
            });
        }
    }
}

//##############################################################################
//###   C h a t M e s s a g e
//##############################################################################
function ChatMessage() {
    this.text = "";
    this.timeStamp = "";
    this.partyType = "";
    
    /////////////////////////////////////////////////////////////
    this.ParseFromJson = function (json) {
        this.text = json.Text;
        this.timeStamp = json.TimeStamp;
        this.partyType = json.PartyType;
    }
}


//##############################################################################
//###   C h a t T e x t E v e n t
//##############################################################################
function ChatTextEvent() {
    this.type = "";
    this.roomId = "";
    this.label = "";
    this.message = "";
    this.partyType = "";
    this.timeStamp = "";

    /////////////////////////////////////////////////////////////
    this.ParseFromJson = function (json) {
        this.type = json.Type;
        this.roomId = json.RoomId;
        this.label = json.Label;
        this.message = json.Message;
        this.partyType = json.PartyType;
        this.timeStamp = json.TimeStamp;
    }
}


//##############################################################################
//###   H o u r s O f O p e r a t i o n E v e n t
//##############################################################################
function HoursOfOperationEvent() {
    this.type = "";
    this.showContinueReskill = "";

    /////////////////////////////////////////////////////////////
    this.ParseFromJson = function (json) {
        this.type = json.Type;
        this.showContinueReskill = json.ShowContinueReskill;
    }
}


//##############################################################################
//###   A g e n t E r r o r E v e n t
//##############################################################################
function AgentErrorEvent() {
    this.type = "";
    this.command = "";
    this.contactId = "";
    this.errorLevel = "";
    this.resultCode = "";
    this.target = "";

    /////////////////////////////////////////////////////////////
    this.ParseFromJson = function (json) {
        this.type = json.Type;
        this.command = json.Command;
        this.contactId = json.ContactId;
        this.errorLevel = json.ErrorLevel;
        this.resultCode = json.ResultCode;
        this.target = json.Target;
    }
}


//##############################################################################
//###   U n a v a i l a b l e C o d e s
//##############################################################################
function UnavailableCodes() {
    this.agentTimeout = "";
    this.businessUnitId = "";
    this.isActive = "";
    this.isAcw = "";
    this.outTsateDescription = "";
    this.outStateId = "";

    /////////////////////////////////////////////////////////////
    this.ParseFromJson = function (json) {
        this.agentTimeout = json.AgentTimeout;
        this.businessUnitId = json.BusinessUnitId;
        this.isActive = json.IsActive;
        this.isAcw = json.IsAcw;
        this.outTsateDescription = json.OutTsateDescription;
        this.outStateId = json.OutStateId;
    }
}


//##############################################################################
//###   A g e n t I n f o
//##############################################################################
function AgentInfo() {
    this.AgentId = "";
    this.BusinessUnitId = "";
    this.Custom1 = "";
    this.Custom2 = "";
    this.Custom3 = "";
    this.Custom4 = "";
    this.Custom5 = "";
    this.Email = "";
    this.FirstName = "";
    this.InternalId = "";
    this.IsActive = "";
    this.IsSupervisor = "";
    this.LastLogin = "";
    this.LastModified = "";
    this.LastName = "";
    this.Location = "";
    this.MiddleName = "";
    this.ReportToFirstName = "";
    this.ReportToId = "";
    this.ReportToLastName = "";
    this.ReportToMiddleName = "";
    this.TeamId = "";
    this.TeamName = "";
    this.UserName = "";

    /////////////////////////////////////////////////////////////
    this.ParseFromJson = function (json) {
        this.agentId = json.AgentId;
        this.businessUnitId = json.BusinessUnitId;
        this.custom1 = json.Custom1;
        this.custom2 = json.Custom2;
        this.custom3 = json.Custom3;
        this.custom4 = json.Custom4;
        this.custom5 = json.Custom5;
        this.email = json.Email;
        this.firstName = json.FirstName;
        this.internalId = json.InternalId;
        this.isActive = json.IsActive;
        this.isSupervisor = json.IsSupervisor;
        this.lastLogin = json.LastLogin;
        this.lastModified = json.LastModified;
        this.lastName = json.LastName;
        this.location = json.Location;
        this.middleName = json.MiddleName;
        this.reportToFirstName = json.ReportToFirstName;
        this.reportToId = json.ReportToId;
        this.reportToLastName = json.ReportToLastName;
        this.reportToMiddleName = json.ReportToMiddleName;
        this.teamId = json.TeamId;
        this.teamName = json.TeamName;
        this.userName = json.UserName;
    }
}

//##############################################################################
//###   A g e n t S k i l l A s s i g n m e n t 
//##############################################################################

function AgentSkillAssignments() {
    this.businessUnitId;
    this.agentId;
    this.internalId;
    this.agentName;
    this.agentProficiencyValue;
    this.agentProficiencyName;
    this.lastModified;
    this.skillName;
    this.skillId;

    this.ParseFromJson = function (json) {
        this.businessUnitId = json.BusinessUnitId;
        this.agentId = json.AgentId;
        this.internalId = json.InternalId;
        this.agentName = json.AgentName;
        this.agentProficiencyValue = json.AgentProficiencyValue;
        this.agentProficiencyName = json.AgentProficiencyName;
        this.lastModified = json.LastModified;
        this.skillName = json.SkillName;
        this.skillId = json.SkillId;
    }
}

//##############################################################################
//###   S k i l l D i s p o s i t i o n s 
//##############################################################################

function SkillDispositions() {

    var self = this;

    self.skillName;
    self.skillId;
    self.dispositionCodes = new Array();

    self.ParseFromJson = function (json) {
        self.skillName = json.SkillName;
        self.skillId = json.SkillId;
        $.each(json.DispositionCodes, function () {
            var dispositionCode = new DispositionCode();
            dispositionCode.dispositionId = this.DispositionId;
            dispositionCode.dispositionName = this.DispositionName;
            dispositionCode.displayOrder = this.DisplayOrder;
            self.dispositionCodes[self.dispositionCodes.length] = dispositionCode;
        });
    }
}

//##############################################################################
//###   D i s p o s i t i o n C o d e
//##############################################################################

function DispositionCode() {
    this.dispositionId;
    this.dispositionName;
    this.displayOrder;
}

//##############################################################################
//###   S k i l l 
//##############################################################################

function Skill() {
    this.businessUnitId;
    this.skillId;
    this.skillName;
    this.mediaTypeName;
    this.mediaTypeId;
    this.isActive;
    this.campaignId;
    this.campaignName;
    this.isOutbound;
    this.isDialer;
    this.notes;
    this.useACW;
    this.useDisposition;
    this.requireDisposition;

    this.ParseFromJson = function (json) {
        this.businessUnitId = json.BusinessUnitId;
        this.skillId = json.SkillId;
        this.skillName = json.SkillName;
        this.mediaTypeName = json.MediaTypeName;
        this.mediaTypeId = json.MediaTypeId;
        this.isActive = json.IsActive;
        this.campaignId = json.CampaignId;
        this.campaignName = json.CampaignName;
        this.isOutbound = json.IsOutbound;
        this.isDialer = json.IsDialer;
        this.notes = json.Notes;
        this.useACW = json.UseACW;
        this.useDisposition = json.UseDisposition;
        this.requireDisposition = json.RequireDisposition;
    }
}


//##############################################################################
//###   S k i l l Q u e u e 
//##############################################################################

function SkillQueue() {
    this.businessUnitId;
    this.skillId;
    this.skillName;
    this.campaignId;
    this.mediaType;
    this.queueCount;
    this.LongestQueueTimeInSeconds;
    this.EarliestQueueTimeInUTC;

    this.ParseFromJson = function (json) {
        this.businessUnitId = json.BusinessUnitId;
        this.skillId = json.SkillId;
        this.skillName = json.SkillName;
        this.campaignId = json.CampaignId;
        this.mediaTypeId = json.MediaTypeId;
        this.queueCount = json.QueueCount;
        this.longestQueueTimeInSeconds = json.LongestQueueTimeInSeconds;
        this.EarliestQueueTimeInUTC = json.earliestQueueTimeInUTC;
    }
}


//##############################################################################
//###   S t o r a g e
//##############################################################################

////////////////////////////////////////////////////////////
// localStorageGet
//     Gets a value from localStorage, or returns a default value if the key
//     does not exist.
//
function localStorageGet(key, defaultValue) {
    if (localStorage) {
        var value = localStorage[key];
        if (value !== undefined && value != "undefined")
            return value;
    }

    if (defaultValue === undefined || defaultValue == "undefined")
        return null;
    return defaultValue;
}


////////////////////////////////////////////////////////////
// localStorageClear
//     Clears a key from localStorage.
//
function localStorageClear(key) {
    if (localStorage)
        localStorage.removeItem(key);
}


////////////////////////////////////////////////////////////
// sessionStorageGet
//     Gets a value from sessionStorage, or returns a default value if the key
//     does not exist.
// 
function sessionStorageGet(key, defaultValue) {
    if (sessionStorage) {
        var value = sessionStorage[key];
        if (value !== undefined && value != "undefined")
            return value;
    }

    if (defaultValue === undefined || defaultValue == "undefined")
        return null;
    return defaultValue;
}
