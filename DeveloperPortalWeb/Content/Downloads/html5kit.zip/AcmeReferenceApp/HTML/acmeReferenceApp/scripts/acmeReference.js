//##############################################################################
//###   Common functions
//##############################################################################
function namespace(namespaceString) {
    var parts = namespaceString.split('.'),
        parent = window,
        currentPart = '';

    for (var i = 0, length = parts.length; i < length; i++) {
        currentPart = parts[i];
        parent[currentPart] = parent[currentPart] || {};
        parent = parent[currentPart];
    }

    return parent;
};

namespace('acme.common');

//##############################################################################
//###   Date&Time Functions
//##############################################################################
acme.common.getFormattedTime = function (milliseconds) {
    var result = "";
    var totalSeconds = Math.floor(milliseconds / 1000);
    if (totalSeconds < 0)
        totalSeconds = 0;

    var seconds = totalSeconds % 60;
    var minutes = Math.floor(totalSeconds / 60) % 60;
    var hours = Math.floor(totalSeconds / 3600);

    if (seconds < 10)
        seconds = "0" + seconds;

    if (minutes < 10)
        minutes = "0" + minutes;

    if (hours <= 0)
        return minutes + ":" + seconds;
    else
        return hours + ":" + minutes + ":" + seconds;
}

acme.common.getFormattedDate = function (dateString) {
    var result = "";

    var date = new Date(dateString);

    var day = date.getDate();
    var month = date.getMonth();
    var year = date.getFullYear();

    if (day < 10)
        day = "0" + day;

    if (month < 10)
        month = "0" + month;

    return month + "/" + day + "/" + year;
}

//##############################################################################
//###   Lookup Table
//##############################################################################
acme.common.lookupTable = {
    "HeldPartyAbandoned": function () {
        return "Held Party Abandoned";
    },
    "InboundContact": function () {
        return "Inbound Contact";
    },
    "OutboundContact": function () {
        return "Outbound Contact";
    },
    "PromisePending": function () {
        return "Promise Pending";
    },
    "BadNumber": function () {
        return "Bad Number";
    },
    "CallAbandoned": function () {
        return "Call Abandoned";
    }
};

//##############################################################################
//###   Compatibility
//##############################################################################
if (!String.prototype.trim) {
    String.prototype.trim = function () {
        return this.replace(/^\s+|\s+$/g, '');
    };
}
