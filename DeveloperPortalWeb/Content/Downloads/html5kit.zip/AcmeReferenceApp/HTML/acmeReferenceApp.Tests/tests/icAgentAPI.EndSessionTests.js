var validUserName = localStorage["username"];
var validPassword = localStorage["password"];
var validPhoneNumber = "4008021107";

/*********************************************
* A G E N T   E N D    M O D U L E
*********************************************/
module("End Session Tests", {
    //Executed at the begining of each test
    setup: function () {
        stop();

        //validate client & credentials
        if (localStorage["tokenServiceUri"] == undefined)
            ok(false, "The authorizationServerUri must be setup first");

        if (localStorage["clientId"] == undefined)
            ok(false, "The clientId must be setup first");

        if (localStorage["clientSecret"] == undefined)
            ok(false, "The clientSecret must be setup first");

        function onSuccess() {
            ok(true, "Agent session started");
            start();
        }

        function onError(error) {
            ok(false, "Agent session not started ");
            start();
        }

        //Authenticate
        icAgentAPI.authenticate(validUserName, validPassword, null, null);

        //start session
        setTimeout(function () {
            icAgentAPI.startSession(validPhoneNumber, null, onSuccess, onError);
        }, 3000);
    },
    //Executed at the end of each test
    teardown: function () {
    }
});

asyncTest("Should end session", 2, function (assert) {
    function onSuccess() {
        ok(true, "Agent session ended.");
        start();
    }

    function onError(error) {
        ok(false, "Agent didn't end session as expected. Error: " + error.statusDescription);
        start();
    }

    icAgentAPI.endSession(false, false, false, onSuccess, onError);
});