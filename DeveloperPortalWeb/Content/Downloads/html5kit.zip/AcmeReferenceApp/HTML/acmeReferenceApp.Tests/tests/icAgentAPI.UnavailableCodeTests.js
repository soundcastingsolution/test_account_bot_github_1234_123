var applicationId = localStorage["clientId"] + ":" + localStorage["clientSecret"];
var userName = localStorage["username"];
var password = localStorage["password"];
var teamid = "1000"; //Team by default

/*********************************************
* U N A V A I L A B L E  C O D E S  M O D U L E
*********************************************/
module("Unavailable Code Tests", {
    //Executed at the begining of each test
    setup: function () {
        stop();

        //validate client & credentials
        if (localStorage["tokenServiceUri"] == undefined)
            ok(false, "The authorizationServerUri must be setup first");

        if (localStorage["clientId"] == undefined)
            ok(false, "The clientId must be setup first");

        if (localStorage["clientSecret"] == undefined)
            ok(false, "The clientSecret must be setup first");

        function onSuccess() {
            ok(true, "Agent session started");
            start();
        }

        function onError(error) {
            ok(false, "Agent session not started ");
            start();
        }

        //Authenticate
        icAgentAPI.authenticate(validUserName, validPassword, null, null);

        //start session
        setTimeout(function () {
            icAgentAPI.startSession(validPhoneNumber, null, onSuccess, onError);
        }, 3000);
    },
    //Executed at the end of each test
    teardown: function () {
        icAgentAPI.endSession(false, false, false, null, null);
    }
});

asyncTest("Should return team unavailable codes", 3, function (assert) {
    function onSuccess(data) {
        ok(true, "Success callback returned.");
        ok(data != null, "Unavailable list is not null, contains " + data.length + " elements");
        start();
    }

    function onError(error) {
        ok(false, "Unable to get unavailable codes");
        start();
    }

    icAgentAPI.getUnavailableCodes(teamid, onSuccess, onError);
});
