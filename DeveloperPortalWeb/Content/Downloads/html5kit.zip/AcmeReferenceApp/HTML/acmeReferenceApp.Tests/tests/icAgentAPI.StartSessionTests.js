var validUserName = localStorage["username"];
var validPassword = localStorage["password"];
var invalidUserName = "badUser@incontact.com";
var invalidPassword = "badPassword";
var validPhoneNumber = "4008021107";

/*********************************************
* S T A R T   S E S S I O N    M O D U L E
*********************************************/
module("Start Session Tests", {
    //Validate required setup
    setup: function () {
        if (localStorage["tokenServiceUri"] == undefined)
            ok(false, "The authorizationServerUri must be setup first");

        if (localStorage["clientId"] == undefined)
            ok(false, "The clientId must be setup first");

        if (localStorage["clientSecret"] == undefined)
            ok(false, "The clientSecret must be setup first");
    },
    teardown: function () {
        // clean up after each test
    }
});

asyncTest("Should start session when user is authenticated", 1, function (assert) {
    function onSuccess(data) {
        ok(true, "Agent session was started.");
    };

    function onError(error) {
        ok(false, "Agent session was not not started.  Error: " + error.statusDescription);
    };

    icAgentAPI.authenticate(validUserName, validPassword, null, null);

    setTimeout(function () {
        icAgentAPI.startSession(validPhoneNumber, null, onSuccess, onError);

        setTimeout(function () {
            icAgentAPI.endSession(false, false, false, null, null);

            setTimeout(function () { start(); }, 3000);
        }, 3000);
    }, 3000);
});

asyncTest("Should not start session when user is not authenticated", 1, function (assert) {
    function onSuccess(data) {
        ok(false, "A failed start session was expected.");
        start();
    }

    function onError(error) {
        ok(true, "Agent not start session.");
        start();
    }

    icAgentAPI.startSession(validPhoneNumber, null, onSuccess, onError);
});

asyncTest("Should not start session when both station and phone number are null", 1, function (assert) {
    function onSuccess(data) {
        ok(false, "A failed start session was expected.");
        start();
    }

    function onError(error) {
        ok(true, "Agent not start session.");
        start();
    }

    icAgentAPI.authenticate(validUserName, validPassword, null, null);

    setTimeout(function () {
        icAgentAPI.startSession(null, null, onSuccess, onError);
    }, 3000);
});