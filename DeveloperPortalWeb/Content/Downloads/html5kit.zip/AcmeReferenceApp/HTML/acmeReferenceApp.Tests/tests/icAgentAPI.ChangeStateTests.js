var validUserName = localStorage["username"];
var validPassword = localStorage["password"];
var validPhoneNumber = "4008021107";
var availableState = "Available";
var unavailableState = "Unavailable";
var wrongState = "WRONG_STATE";

/*********************************************
* A G E N T   S T A T E    M O D U L E
*********************************************/
module("Agent State Tests", {
    //Executed at the begining of each test
    setup: function () {
        stop();

        //validate client & credentials
        if (localStorage["tokenServiceUri"] == undefined)
            ok(false, "The authorizationServerUri must be setup first");

        if (localStorage["clientId"] == undefined)
            ok(false, "The clientId must be setup first");

        if (localStorage["clientSecret"] == undefined)
            ok(false, "The clientSecret must be setup first");

        function onSuccess() {
            ok(true, "Agent session started");
            start();
        }

        function onError(error) {
            ok(false, "Agent session not started ");
            start();
        }

        //Authenticate
        icAgentAPI.authenticate(validUserName, validPassword, null, null);

        //start session
        setTimeout(function () {
            icAgentAPI.startSession(validPhoneNumber, null, onSuccess, onError);
        }, 3000);
    },
    //Executed at the end of each test
    teardown: function () {
        icAgentAPI.endSession(false, false, false, null, null);
    }
});

asyncTest("Should set agent state to Available", 2, function (assert) {
    function onSuccess() {
        ok(true, "Agent State Changed.");
        start();
    }

    function onError(error) {
        ok(false, "Agent didn't change its state as expected. Error: " + error.statusDescription);
        start();
    }

    icAgentAPI.setAgentState(availableState, null, onSuccess, onError);
});

asyncTest("Should set agent state to Unabailable", 2, function (assert) {
    function onSuccess() {
        ok(true, "Agent State Changed.");
        start();
    }

    function onError(error) {
        ok(false, "Agent didn't change its state as expected. Error: " + error.statusDescription);
        start();
    }

    icAgentAPI.setAgentState(unavailableState, null, onSuccess, onError);
});

asyncTest("Should not set agent state to a wrong state", 2, function (assert) {
    function onSuccess() {
        ok(false, "Agent State Error was expected.");
        start();
    }

    function onError(error) {
        ok(true, "Agent state can't be changed.");
        start();
    }

    icAgentAPI.setAgentState(wrongState, null, onSuccess, onError);
});