var validUserName = localStorage["username"];
var validPassword = localStorage["password"];
var invalidUserName = "badUser@incontact.com";
var invalidPassword = "badPassword";

/*********************************************
* A U T H E N T I C A T I O N    M O D U L E
*********************************************/
module("Authentication Tests", {
    //Validate required setup
    setup: function () {
        if (localStorage["tokenServiceUri"] == undefined)
            ok(false, "The authorizationServerUri must be setup first");

        if (localStorage["clientId"] == undefined)
            ok(false, "The clientId must be setup first");

        if (localStorage["clientSecret"] == undefined)
            ok(false, "The clientSecret must be setup first");
    },
    teardown: function () {
        // clean up after each test
    }
});

asyncTest("Should authenticate user with valid credentials", 1, function (assert) {
    function onSuccess() {
        ok(true, "Agent was successfully authenticated.");
        start();
    }

    function onError(error) {
        ok(false, "Failed to authenticate user \"" + validUserName + "\". Error: " + error.statusDescription);
        start();
    }

    icAgentAPI.authenticate(validUserName, validPassword, onSuccess, onError);
});

asyncTest("Should not authenticate user with wrong password", 1, function (assert) {
    function onSuccess() {
        ok(false, "A failed authentication was expected.");
        start();
    }

    function onError(error) {
        ok(true, "Agent was not authenticated.");
        start();
    }

    icAgentAPI.authenticate(validUserName, invalidPassword, onSuccess, onError);
});

asyncTest("Should not authenticate user with wrong password", 1, function (assert) {
    function onSuccess() {
        ok(false, "A failed authentication was expected.");
        start();
    }

    function onError(error) {
        ok(true, "Agent was not authenticated.");
        start();
    }

    icAgentAPI.authenticate(validUserName, invalidPassword, onSuccess, onError);
});