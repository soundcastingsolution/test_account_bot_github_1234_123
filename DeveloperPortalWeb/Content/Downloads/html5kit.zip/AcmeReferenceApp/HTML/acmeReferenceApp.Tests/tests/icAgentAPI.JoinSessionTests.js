var userName = localStorage["username"];
var password = localStorage["password"];
var phoneNumber = "4008021107"

/*********************************************
* J O I N   S E S S I O N    M O D U L E
*********************************************/
module("Join Session Tests", {
    //Executed at the begining of each test
    setup: function () {
        stop();

        //validate client & credentials
        if (localStorage["tokenServiceUri"] == undefined)
            ok(false, "The authorizationServerUri must be setup first");

        if (localStorage["clientId"] == undefined)
            ok(false, "The clientId must be setup first");

        if (localStorage["clientSecret"] == undefined)
            ok(false, "The clientSecret must be setup first");

        function onSuccess() {
            ok(true, "Agent authenticated");
            start();
        }

        function onError(error) {
            ok(false, "Agent not authenticated");
            start();
        }

        //Authenticate
        icAgentAPI.authenticate(validUserName, validPassword, onSuccess, onError);
    },
    //Executed at the end of each test
    teardown: function () {
        icAgentAPI.endSession(false, false, false, null, null);
    }
});

asyncTest("Should Join session", 2, function (assert) {
    function onSuccess(data) {
        ok(true, "Success callback returned.");
        start();
    }

    function onError(error) {
        ok(false, "Unable to join session");
        start();
    }

    function onStartSessionSuccess(data) {
         icAgentAPI.joinSession(onSuccess, onError);
    }

    function onStartSessionError(error) {
        ok(false, "Unknown start session error");
    }

    icAgentAPI.startSession(phoneNumber, null, onStartSessionSuccess, onStartSessionError);
});