var userName = localStorage["username"];
var password = localStorage["password"];
var phoneNumber = "4008021107"
var agentId = "1010";

/*********************************************
* A G E N T   I N F O    M O D U L E
*********************************************/
module("Agent Info Tests", {
    //Executed at the begining of each test
    setup: function () {
        stop();

        //validate client & credentials
        if (localStorage["tokenServiceUri"] == undefined)
            ok(false, "The authorizationServerUri must be setup first");

        if (localStorage["clientId"] == undefined)
            ok(false, "The clientId must be setup first");

        if (localStorage["clientSecret"] == undefined)
            ok(false, "The clientSecret must be setup first");

        function onSuccess() {
            ok(true, "Agent session started");
            start();
        }

        function onError(error) {
            ok(false, "Agent session not started ");
            start();
        }

        //Authenticate
        icAgentAPI.authenticate(validUserName, validPassword, null, null);

        //start session
        setTimeout(function () {
            icAgentAPI.startSession(validPhoneNumber, null, onSuccess, onError);
        }, 3000);
    },
    //Executed at the end of each test
    teardown: function () {
        icAgentAPI.endSession(false, false, false, null, null);
    }
});

asyncTest("Should return agent info", 3, function () {
    function onSuccess(data) {
        ok(true, "Agent Info Loaded.");
        ok(data.userName === userName, "returns info of the requested agent");
        start();
    }

    function onError(error) {
        ok(false, "Unable to get agent info");
        start();
    }

    icAgentAPI.getAgentInfo(agentId, onSuccess, onError);
});