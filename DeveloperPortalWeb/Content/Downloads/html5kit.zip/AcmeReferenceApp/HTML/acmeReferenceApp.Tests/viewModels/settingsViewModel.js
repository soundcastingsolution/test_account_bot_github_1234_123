function settingsViewModel() {
    var self = this;

    self.tokenServiceUri = ko.observable();
    self.clientId = ko.observable();
    self.clientSecret = ko.observable();

    self.userName = ko.observable();
    self.password = ko.observable();

    self.saveSettings = function () {
        localStorage["tokenServiceUri"] = self.tokenServiceUri();
        localStorage["clientId"] = self.clientId();
        localStorage["clientSecret"] = self.clientSecret();

        localStorage["username"] = self.userName();
        localStorage["password"] = self.password();
    };

    self.loadSettings = function () {
        self.tokenServiceUri(localStorage["tokenServiceUri"]);
        self.clientId(localStorage["clientId"]);
        self.clientSecret(localStorage["clientSecret"]);

        self.userName(localStorage["username"]);
        self.password(localStorage["password"]);
    };

    self.loadSettings();
}