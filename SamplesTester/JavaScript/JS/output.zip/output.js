
function ConstructArray(APIName,APISubType,APIType,Version,response)
{
	/*var table = document.getElementById("customers");
    var row = table.insertRow(1);
    var APINameCell = row.insertCell(0);
    var APISubTypeCell = row.insertCell(1);
	var APITypeCell = row.insertCell(2);  
	var VersionCell = row.insertCell(3);
	var responseCell = row.insertCell(4);
	
	APINameCell.innerHTML = APIName;
	APISubTypeCell.innerHTML = APISubType;
	APITypeCell.innerHTML = APIType;
	VersionCell.innerHTML = Version;
	responseCell.innerHTML = response;*/


 var addNewReuslt = "<tr><td>" + APIName + "</td><td>" + APISubType +" </td><td>" +APIType+ "</td><td>" +Version + "</td><td>" +response+"</td></tr>";
 $( "#customers" ).append( addNewReuslt );
 
 // sorting result
 SortingResult();
}

function GenerateOutput()
{
	getAgentSkillsByAgentId('210452','','','','','','','','');
	PutAgentbyAgentID('210452');
	GetagentbyAgentID('210452');
	GetAgentByAgentIDGroups('210452','');
	PostAgentMessages('hi','2018-02-07T06:22:27.143Z','hi','210452','Agent','2018-02-07T06:23:27.143Z','5');
	deleteAgentMessagesByMessageId('12345');
	getTeam('','','','','','','');
	PutTeam();
	PutTeambyTeamID('38077');
	GetTeamAgent('','');
	GetTeamByAgentID('38077','');
	

	GetBrandingProfile('1043','');
	GetDispostion('','','','','','','');
	DeleteFiles('sample');
	
	PostCreateFileName('rafiqSample', 'MTAwMQlNaXNzaW5nIEV4dGVybmFsIElELg0KMTAwMglNaXNzaW5nIEV4dGVybmFsIElELg0KMTAwMwlNaXNzaW5nIEV4dGVybmFsIElELg0KMTAwNAlNaXNzaW5nIEV4dGVybmFsIElELg0KMTAwNQlNaXNzaW5nIEV4dGVybmFsIElELg0KMTAwNglNaXNzaW5nIEV4dGVybmFsIElELg0K', 'true');
	
	PutupdateFile( 'rafiqSample', 'rafiqSample', true);
	GetFilesExternal('CallingLists');
	PostCreateFileExternal('testfile','MTAwMQlNaXNzaW5nIEV4dGVybmFsIElELg0KMTAwMglNaXNzaW5nIEV4dGVybmFsIElELg0KMTAwMwlNaXNzaW5nIEV4dGVybmFsIElELg0KMTAwNAlNaXNzaW5nIEV4dGVybmFsIElELg0KMTAwNQlNaXNzaW5nIEV4dGVybmFsIElELg0KMTAwNglNaXNzaW5nIEV4dGVybmFsIElELg0K',true,true);
	PutupdateFilesExternal('testfile',false);
	DeleteFolders('folderName');
	GetFolders('CallingLists');
	PostcreateDispositions('dip2332',false,'5');
	GetDispostionByID('4552');
	PutUpdateDispostionbydispositionId('5','dip2332',false,1, true);
	GetDispostionByClassification('');
	PostCreateSkill();
	PutSkillbySkillID('162779');
	GetDispostionBySkillid('162779','','','','','' );
	GetDispostionBySkillidUnAssigned('162779','','','','','');
	GetSkillParameterGeneralSetting('165455',''); // personal call skill id
	PutSkillParameterGeneralSetting('165455'); // personal call skill id
	GetcontactbyContactID('2233650423','');
	GetListCalllist('','','','','2017-09-15T15:53:00','2017-09-15T15:53:00');
	PostCallListbyListID('1001',162779,'',true,'','','',false);
	DeleteCallListByJobID('1001'); // job ID is sample
	GetCallingListbyJobID('1001');
	GetGroups('','','','','','');
	PostGroups('sample',true,'sample');
	GetGroupsByGroupID('10001','');    //sample Group ID
	PutGroupsByGroupID('10001','sample',true,'sample');   // sample Group ID
	DeleteGroupsByAgentGroupID('10001',101212); // sample Group ID
	GetGroupsByAgentGroupID('10001','','','','','','');// sample Group ID
	PostGroupsByAgentGroupID('10001',101212);// sample Group ID
	postSessionIdInteractionsContactIdtyping('QzJWa2JUZUthTmcwb1dPMXcwd2xTa2FJamY3QTZGQ25wUFlVR1FTZzF1Tld4Tm89', '2237919812',true,true);
	posttAgentSessionSessionIdInteractionAddEmail('QzJWa2JUZUthTmcwb1dPMXcwd2xTa2FJamY3QTZGQ25wUFlVR1FTZzF1Tld4Tm89');
	posttAgentSessionIdInteractionConatactIdParkemail('QzJWa2JUZUthTmcwb1dPMXcwd2xTa2FJamY3QTZGQ25wUFlVR1FTZzF1Tld4Tm89','2237919921');
	posttAgentSessionIdInteractionConatactIdUnparkemail( 'QzJWa2JUZUthTmcwb1dPMXcwd2xTa2FJamY3QTZGQ25wUFlVR1FTZzF1Tld4Tm89', '2237919921');
	posttAgentSessionIdInteractionConatactIdPreview( 'QzJWa2JUZUthTmcwb1dPMXcwd2xTa2FJamY3QTZGQ25wUFlVR1FTZzF1Tld4Tm89', '2237919921')
	posttAgentSessionIdInteractionConatactIdEmailRestore('QzJWa2JUZUthTmcwb1dPMXcwd2xTa2FJamY3QTZGQ25wUFlVR1FTZzF1Tld4Tm89', '2237919921');
	posttAgentSessionIdInteractionConatactIdSnooze( 'QzJWa2JUZUthTmcwb1dPMXcwd2xTa2FJamY3QTZGQ25wUFlVR1FTZzF1Tld4Tm89', '2237919921')
}


function SortingResult(){
var table, rows, switching, i, x, y, shouldSwitch;
  table = document.getElementById("customers");
  switching = true;
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.getElementsByTagName("TR");
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[1];
	  

      y = rows[i + 1].getElementsByTagName("TD")[1];
      //check if the two rows should switch place:
      if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
        //if so, mark as a switch and break the loop:
        shouldSwitch= true;
        break;
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
  
  /**************************/
  var table = $('table')[0];
var rowGroups = {};
//loop through the rows excluding the first row (the header row)
while(table.rows.length > 1){
    var row = table.rows[1];
    var id = $(row.cells[1]).text();
   
    if(!rowGroups[id]) rowGroups[id] = [];
    if(rowGroups[id].length > 0){
        row.className = 'subrow';
        $(row).slideUp();
    }
    rowGroups[id].push(row);
    table.deleteRow(1);
}
//loop through the row groups to build the new table content
for(var id in rowGroups){
    var group = rowGroups[id];
    for(var j = 0; j < group.length; j++){
        var row = group[j];
        if(group.length > 1 && j == 0) {
            //add + button
            var lastCell = row.cells[row.cells.length - 1];           
            $("<span class='collapsed'>").appendTo(lastCell).click(plusClick);                                         
        }
        table.tBodies[0].appendChild(row);        
    }
}
//function handling button click
function plusClick(e){
    var collapsed = $(this).hasClass('collapsed');
    var fontSize = collapsed ? 14 : 0;
    $(this).closest('tr').nextUntil(':not(.subrow)').slideToggle(400)
           .css('font-size', fontSize);
    $(this).toggleClass('collapsed');        
}

}

