var baseURI = "https://api-sc1.ucnlabext.com/inContactAPI";
//var baseURI = 'https://hc8.ucnlabext.com/InContactAPI'
var accessToken ;
function getAccesstoken(){ 
        var createAuthenticationPayload = {'grant_type': 'password','password': 'Qwerty@123','username' :'nikhil.m@sc1.com'}
		//var createAuthenticationPayload = {'grant_type': 'password','password': 'Servion@123','username' :'rafiq.j@hc8.com'}
        var baseURI='https://api-sc1.ucnlabext.com/';
		//var baseURI = 'http://hc-c8web01.in.lab/'
        $.ajax({
            //The baseURI variable is created by the result.resource_server_base_uri,
            //which is returned when getting a token and should be used to create the URL base
            'url': baseURI + 'InContactAuthorizationServer/Token',
            'type': 'POST',
            'headers': {
                //Use access_token previously retrieved from inContact token service
                'Authorization': 'basic ' + 'aW50ZXJuYWxAaW5Db250YWN0IEluYy46UVVFNVFrTkdSRE0zUWpFME5FUkRSamczUlVORFJVTkRRakU0TlRrek5UYz0=',
                'content-Type': 'application/json'
            },
            'data': JSON.stringify(createAuthenticationPayload),
            'success': function (result, status, statusCode) {
                sessionStorage.setItem("token", result.access_token);
				accessToken = sessionStorage.getItem("token");
				GenerateOutput();
            },
            'error': function (XMLHttpRequest, textStatus, errorThrown) {
                //Process error actions
                return false;
            }
        });

       // getAddressBooks()
        
    }


//Admin--> Agent

function getAgentSkillsByAgentId(AgentID,updatedSince,searchString,fields,skip,top,orderBy,MediaTypeId,outboundStrategy){ // done

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/agents/' + AgentID + '/skills'+ '?fields=' + fields + '&updatedSince=' + updatedSince + 
                '&searchString=' + searchString + '&fields=' + fields + '&skip' + skip + '&top=' + top + '&orderBy=' + orderBy + '&MediaTypeId=' + MediaTypeId + '&outboundStrategy=' + outboundStrategy ,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded',
			'Access-Control-Allow-Origin' : '*',
			async:true
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Agent","GET agents/{agentId}/skills","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Agent","GET agents/{agentId}/skills","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function PutAgentbyAgentID(AgentID){ //done
	var getAllAgentsSkillsPayload = {
  "agent": {
    "firstName": "String",
    "middleName": "",
    "lastName": "String",
    "teamId": "0",
    "reportToId": 0,
    "internalId": "",
    "profileId": 8,
    "emailAddress": "sample@abc.com",
    "userName": "String",
    "userId": "Integer",
    "timeZone": "(GMT-07:00) Arizona",
    "country": "",
    "state": "",
    "city": "",
    "chatRefusalTimeout": 15,
    "phoneRefusalTimeout": 15,
    "workItemRefusalTimeout": 15,
    "defaultDialingPattern": 0,
    "maxConcurrentChats": 1,
    "useTeamMaxConcurrentChats": false,
    "isActive": true,
    "locationId": 0,
    "notes": "",
    "hireDate": "10/10/1800",
    "terminationDate": "10/10/1800",
    "hourlyCost": 0,
    "rehireStatus": true,
    "employmentType": 1,
    "referral": "",
    "atHome": false,
    "hiringSource": 0,
    "ntLoginName": "",
    "custom1": "",
    "custom2": "",
    "custom3": "",
    "custom4": "",
    "custom5": "",
    "scheduleNotification": 0,
    "federatedId": "",
    "maxEmailAutoParkingLimit": 1,
    "useTeamEmailAutoParkingLimit": false,
    "sipUser": "",
    "systemUser": "",
    "systemDomain": "",
    "crmUserName": "",
    "useAgentTimeZone": false,
    "timeDisplayFormat": 0,
    "sendEmailNotifications": false,
    "apiKey": "",
    "telephone1": "",
    "telephone2": "",
    "userType": "agent",
    "isWhatIfAgent": false,
    "requestContact": false,
    "useTeamRequestContact": false,
    "chatThreshold": 1,
    "useTeamChatThreshold": false,
    "emailThreshold": 1,
    "useTeamEmailThreshold": false,
    "workItemThreshold": 1,
    "useTeamWorkItemThreshold": false,
    "contactAutoFocus": false,
    "useTeamContactAutoFocus": false,
    "subject": "",
    "issuer": "",
    "isOpenIdProfileComplete": false,
    "recordingNumbers": [
      {
        "number": ""
      }
    ]
  }
}

    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/agents/' + AgentID,
        'type': 'PUT',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/json; charset=UTF-8',
			'Accept':'application/json, text/javascript, */*; q=0.01'
        },
        'data': JSON.stringify(getAllAgentsSkillsPayload),
        'success': function (result, status, statusCode) {
            //Process success actions
            return result;
			ConstructArray("Admin","Agent","PUT /agents/{agentId}","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","Agent","PUT /agents/{agentId}","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
			
        }
    });
}
function GetagentbyAgentID(AgentId){ // done
	getAllAgentsSkillsPayload = {
		'updatedSince': 'string - ISO 8601 formatted date/time',
		'searchString': 'string',
		'fields': 'string',
		'skip': 'integer',
		'top': 'integer',
		'orderBy': 'string'
	}
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/agents/' + AgentId ,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		//'data':JSON.stringify(getAllAgentsSkillsPayload),
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Agent","GET /agents/{agentId}","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Agent","GET /agents/{agentId}","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function GetAgentByAgentIDGroups(AgentId,fields){//done
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/agents/' + AgentId + '/groups' + '?fields=' + fields,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Agent","GET /agents/{agentId}/groups","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Agent","GET /agents/{agentId}/groups","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function PostAgentMessages(message,startDate,subject,targetId,targetType,validUntil,expireMinutes){//done

var createpostmessagesPayload = {
  "agentMessages": [
    {
      "message":  message ,
      "startDate":  startDate ,
      "subject":  subject ,
      "targetId":  targetId ,
      "targetType":  targetType ,
      "validUntil":  validUntil  ,
      "expireMinutes":  expireMinutes 
    }
  ]
}
    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/agents/messages',
        'type': 'POST',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/json; charset=UTF-8'
        },
        'data': JSON.stringify(createpostmessagesPayload),
        'success': function (result, status, statusCode) {
            //Process success actions
			ConstructArray("Admin","Agent","POST /agents/messages","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
            return result;
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","Agent","POST /agents/messages","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
        }
    });
}
function deleteAgentMessagesByMessageId(MessageId) { //done

    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/agents/messages/' + MessageId,
        'type': 'DELETE',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/x-www-form-urlencoded'
        },
        'success': function (result, status, statusCode) {
            //Process success actions
			ConstructArray("Admin","Agent","DELETE /agents/messages/{messageid}","SC1-v11.0",statusCode.status + ":" + statusCode.statusTex);
            return result;
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","Agent","DELETE /agents/messages/{messageid}","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
        }
    });
}
function getTeam(fields,updatedSince,searchString,fields,skip,top,orderBy){//done
	
	var queryString = "?fields=" + fields + "&updatedSince=" + updatedSince + 
                "&searchString=" + searchString + "&fields=" + fields + "&skip" + skip + 
                "&top=" + top + "&orderBy=" + orderBy;
    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/teams' + queryString,
        'type': 'GET',
		'async': false,
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken ,
            'content-Type': 'application/x-www-form-urlencoded',
			'Access-Control-Allow-Origin' : '*'
        },
        'success': function (result, status, statusCode) {
       ConstructArray("Admin","Agent","GET /teams","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
	 //Process success actions
	 return result;
			
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
			ConstructArray("Admin","Agent","GET /teams","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            //Process error actions
            return false;
        }
    });
}
function PutTeam(){//done
	
	var POSTTeamPayload = {
  "teams": [
    {
      "teamName": "team",
      "isActive": true,
      "maxConcurrentChats": 8,
      "wfoEnabled": false,
      "wfm2Enabled": false,
      "qm2Enabled": false,
      "inViewEnabled": false,
      "notes": "",
      "maxEmailAutoParkingLimit": 25,
      "inViewGamificationEnabled": false,
      "inViewChatEnabled": false,
      "inViewLMSEnabled": false,
      "analyticsEnabled": false,
      "requestContact": false,
      "chatThreshold": 1,
      "emailThreshold": 1,
      "workItemThreshold": 1,
      "voiceThreshold": 1,
      "contactAutoFocus": false,
      "teamUuid": ""
    }
  ]
}
    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/teams',
        'type': 'PUT',
		'async': false,
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken ,
            'content-Type': 'application/x-www-form-urlencoded',
			'Access-Control-Allow-Origin' : '*'
        },
		'data': JSON.stringify(POSTTeamPayload),
        'success': function (result, status, statusCode) {
       ConstructArray("Admin","Agent","PUT /teams","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
	 //Process success actions
	 return result;
			
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
			ConstructArray("Admin","Agent","PUT /teams","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            //Process error actions
            return false;
        }
    });
}
function PutTeambyTeamID(Teamid) { //done
	
  var updateTeambyTeamIdPayload = {
  "forceInactive": false,
  "team": {
    "teamName": "TeamName",
    "isActive": true,
    "maxConcurrentChats": 8,
    "wfoEnabled": false,
    "wfm2Enabled": false,
    "qm2Enabled": false,
    "inViewEnabled": false,
    "notes": "",
    "maxEmailAutoParkingLimit": 25,
    "inViewGamificationEnabled": false,
    "inViewChatEnabled": false,
    "inViewLMSEnabled": false,
    "analyticsEnabled": false,
    "requestContact": false,
    "chatThreshold": 1,
    "emailThreshold": 1,
    "workItemThreshold": 1,
    "voiceThreshold": 1,
    "contactAutoFocus": false,
    "teamUuid": ""
  }
}
    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/V11.0/teams/' + Teamid,
        'type': 'POST',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/json; charset=UTF-8'
        },
        'data': JSON.stringify(updateTeambyTeamIdPayload),
        'success': function (result, status, statusCode) {
            //Process success actions
			ConstructArray("Admin","Agent","PUT /teams/","SC1-v11.0",statusCode.status + ":" + statusCode.statusTex);
            return result;
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","Agent","PUT /teams/","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
        }
    });
}
function GetTeamAgent(fields,updatedSince){//done
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/teams' + '?fields=' + fields + '&updatedSince=' + updatedSince,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Agent","GET /teams/agents","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Agent","GET /teams/agents","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function GetTeamByAgentID(teamId,fields){//done

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/teams/' + teamId +'/agents'+'?fields=' + fields,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Agent","GET /teams/{teamId}/agents","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Agent","GET /teams/{teamId}/agents","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}


// Admin --> General

function GetBrandingProfile(businessUnitId,fields){//done
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/branding-profiles' + '?businessUnitId=' + businessUnitId + '&fields=' + fields,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","General","GET /branding-profiles","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","General","GET /branding-profiles","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function GetDispostion(skip,top,searchString,fields,orderby,isPreviewDispositions,updatedSince){//done
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/dispositions' + '?skip=' + skip + '&top=' + top+ '&searchString=' + searchString+'&fields='+ fields+ '&orderby='+ orderby+ '&isPreviewDispositions='+ isPreviewDispositions+ '&updatedSince='+ updatedSince,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","General","GET /dispositions","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","General","GET /dispositions","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function DeleteFiles(fileName) {//done
var DeleteFiles=
{
  "fileName": fileName
}
    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/files',
        'type': 'DELETE',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/x-www-form-urlencoded'
        },
		'data': JSON.stringify(DeleteFiles),
        'success': function (result, status, statusCode) {
            //Process success actions
			ConstructArray("Admin","General","DELETE /files","SC1-v11.0",statusCode.status + ":" + statusCode.statusTex);
            return result;
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","General","DELETE /files","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
        }
    });
}
function PostCreateFileName(fileName,file,overwrite){//done

var createpostFilePayload = {
  "fileName": fileName,
  "file": file,
  "overwrite": overwrite
}
    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/files',
        'type': 'POST',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/json; charset=UTF-8'
        },
        'data': JSON.stringify(createpostFilePayload),
        'success': function (result, status, statusCode) {
            //Process success actions
			ConstructArray("Admin","General","POST /Files","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
            return result;
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","General","POST /Files","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
        }
    });
}
function PutupdateFile(oldPath, newPath, overwrite ){//done

var PutfilesPayload = {
  "oldPath":  oldPath,
  "newPath":  newPath,
  "overwrite":  overwrite
}
    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/files',
        'type': 'PUT',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/json; charset=UTF-8',
			'Accept':'application/json, text/javascript, */*; q=0.01'
        },
        'data': JSON.stringify(PutfilesPayload),
        'success': function (result, status, statusCode) {
			ConstructArray("Admin","General","PUT /files","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
            //Process success actions
            return result;
			
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","General","PUT /files","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
			
        }
    });
}
function GetFilesExternal(folderPath){ //done
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/files/external' + '?folderPath=' + folderPath,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","General","GET files/external","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","General","GET files/external","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function PostCreateFileExternal(fileName,file,overwrite = true,needsProcessing = true){//done

var CreateFileexternalPayload = {
  "fileName":  fileName,
  "file":  file ,
  "overwrite":  overwrite,
  "needsProcessing":  needsProcessing 
}
    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/files/external',
        'type': 'POST',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/json; charset=UTF-8'
        },
        'data': JSON.stringify(CreateFileexternalPayload),
        'success': function (result, status, statusCode) {
            //Process success actions
			ConstructArray("Admin","General","POST /files/external","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
            return result;
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","General","POST /files/external","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
        }
    });
}
function PutupdateFilesExternal(fileName,needsProcessing = false){//done
	var PutfilesPayload = {
  "fileName":  fileName,
  "needsProcessing":  needsProcessing
}
    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/files/external',
        'type': 'PUT',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/json; charset=UTF-8',
			'Accept':'application/json, text/javascript, */*; q=0.01'
        },
        'data': JSON.stringify(PutfilesPayload),
        'success': function (result, status, statusCode) {
            //Process success actions
            return result;
			ConstructArray("Admin","General","PUT /files/external","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","General","PUT /files/external","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
			
        }
    });
}
function DeleteFolders(folderName) {//done

var DeleteFolder={"folderName":  folderName}

    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/folders',
        'type': 'DELETE',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/x-www-form-urlencoded'
        },
		'data': JSON.stringify(DeleteFolder),
        'success': function (result, status, statusCode) {
            //Process success actions
			ConstructArray("Admin","General","DELETE /folders","SC1-v11.0",statusCode.status + ":" + statusCode.statusTex);
            return result;
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","General","DELETE /folders","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
        }
    });
}
function GetFolders(folderName){//done
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/folders' + '?folderName='+ folderName,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","General","GET /folders","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","General","GET /folders","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}


//Admin--> skills 

function GetDispostionByID(dispositionId,fields){//done
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/dispositions/' + dispositionId + '? fields='+ fields,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Skills","GET /dispositions/{dispositionId}","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Skills","GET /dispositions/{dispositionId}","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function PutUpdateDispostionbydispositionId(dispositionId,dispositionName,isPreviewDisposition,classificationId,isActive){//done

var PutupdateDispostionbyIDpayload = {
  "dispositionName": dispositionName,
  "isPreviewDisposition": isPreviewDisposition,
  "classificationId": classificationId,
  "isActive": isActive
}
    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/dispositions/' + dispositionId,
        'type': 'PUT',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/json; charset=UTF-8',
			'Accept':'application/json, text/javascript, */*; q=0.01'
        },
        'data': JSON.stringify(PutupdateDispostionbyIDpayload),
        'success': function (result, status, statusCode) {
			ConstructArray("Admin","Skills","PUT /dispositions/{dispositionId}","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
            //Process success actions
            return result;
			
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","Skills","PUT /dispositions/{dispositionId}","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
			
        }
    });
}
function GetDispostionByClassification(fields ){//done
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/dispositions/classifications' + '? fields='+ fields,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Skills","GET /dispositions/classifications","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Skills","GET /dispositions/classifications","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function PostcreateDispositions(dispositionvalue,isPreviewDisposition,classificationId){//done
	
	var CreateDispostionpayload ={
  "dispositions": [
    {
      "dispositionName":  dispositionvalue,
      "isPreviewDisposition": isPreviewDisposition ,
      "classificationId": + classificationId
    }
  ]
}
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/dispositions',
		'type': 'POST',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded',
			'content-Type': 'application/json; charset=UTF-8'
		},
		'data': JSON.stringify(CreateDispostionpayload),
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Skills","Post /dispositions","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Skills","Post /dispositions","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function PostCreateSkill(){//done
var CreateSkillPayload = {
  "skills": [
    {
      "mediaTypeId": 4,
      "skillName": "",
      "isOutbound": true,
      "outboundStrategy": "Personal Connection",
      "campaignId": 1,
      "callerIdOverride": "8015554422",
      "emailFromAddress": "test@test.com",
      "emailFromEditable": false,
      "emailBccAddress": "",
      "scriptId": 2,
      "reskillHours": 4,
      "minWFIAgents": 4,
      "interruptible": false,
      "enableParking": false,
      "minWorkingTime": 4,
      "agentless": false,
      "agentlessPorts": 6,
      "notes": "this is a test note",
      "acwTypeId": 3,
      "requireDisposition": false,
      "allowSecondaryDisposition": false,
      "scriptDisposition": false,
      "stateIdACW": 2,
      "maxSecondsACW": 3,
      "acwPostTimeoutStateId": 53,
      "agentRestTime": 4,
      "displayThankyou": false,
      "thankYouLink": "no",
      "popThankYou": true,
      "popThankYouURL": "tester.com",
      "makeTranscriptAvailable": true,
      "transcriptFromAddress": "fromMe@email.com",
      "priorityBlending": false,
      "callSuppressionScriptId": 4,
      "useScreenPops": true,
      "screenPopTriggerEvent": "popTriggerEvent",
      "useCustomScreenPops": false,
      "screenPopType": "webpage",
      "screenPopDetails": "http://not",
      "initialPriority": 4,
      "acceleration": 5,
      "maxPriority": 10,
      "serviceLevelThreshold": 51,
      "serviceLevelGoal": 24,
      "enableShortAbandon": true,
      "shortAbandonThreshold": 123,
      "countShortAbandons": true,
      "countOtherAbandons": true,
      "chatWarningTheshold": 0,
      "agentTypingIndicator": false,
      "patronTypingPreview": false,
      "smsTransportCodeId": null,
      "messageTemplateId": null,
      "deliverMultipleNumbersSerially": false,
      "cradleToGrave": false,
      "priorityInterrupt": false,
      "treatProgressAsRinging": false,
      "preConnectCPAEnabled": false,
      "agentOverrideFax": true,
      "agentOverrideAnsweringMachine": true,
      "agentOverrideBadNumber": true,
      "dispositions": [
        {
          "dispositionId": 1,
          "priority": 1
        }
      ]
    }
  ]
}
    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/skills',
        'type': 'POST',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/json; charset=UTF-8'
        },
        'data': JSON.stringify(CreateSkillPayload),
        'success': function (result, status, statusCode) {
            //Process success actions
			ConstructArray("Admin","General","POST /Skills","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
            return result;
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","General","POST /Skills","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
        }
    });
}
function PutSkillbySkillID(skillId){//done

var PutSkillbySkillIDpayload = {
  "skill": {
    "skillName": "string",
    "isActive": true,
    "campaignId": 2,
    "callerIdOverride": "string",
    "emailFromAddress": "test@test.com",
    "emailFromEditable": false,
    "emailBccAddress": "",
    "scriptId": 2,
    "reskillHours": 4,
    "minWFIAgents": 4,
    "interruptible": false,
    "enableParking": false,
    "minWorkingTime": 4,
    "agentless": false,
    "agentlessPorts": 6,
    "notes": "this is a test note",
    "acwTypeId": 3,
    "requireDisposition": false,
    "allowSecondaryDisposition": false,
    "scriptDisposition": false,
    "stateIdACW": 2,
    "maxSecondsACW": 3,
    "acwPostTimeoutStateId": 53,
    "agentRestTime": 4,
    "displayThankyou": false,
    "thankYouLink": "no",
    "popThankYou": true,
    "popThankYouURL": "tester.com",
    "makeTranscriptAvailable": true,
    "transcriptFromAddress": "fromMe@email.com",
    "priorityBlending": false,
    "callSuppressionScriptId": 4,
    "useScreenPops": true,
    "screenPopTriggerEvent": "bleh",
    "useCustomScreenPops": false,
    "screenPopType": "webpage",
    "screenPopDetails": "http://no",
    "initialPriority": 4,
    "acceleration": 5,
    "maxPriority": 10,
    "serviceLevelThreshold": 51,
    "serviceLevelGoal": 24,
    "enableShortAbandon": true,
    "shortAbandonThreshold": 123,
    "countShortAbandons": true,
    "countOtherAbandons": true,
    "chatWarningTheshold": 0,
    "agentTypingIndicator": false,
    "patronTypingPreview": false,
    "smsTransportCodeId": null,
    "messageTemplateId": null,
    "deliverMultipleNumbersSerially": false,
    "cradleToGrave": false,
    "priorityInterrupt": false,
    "treatProgressAsRinging": false,
    "preConnectCPAEnabled": false,
    "agentOverrideFax": true,
    "agentOverrideAnsweringMachine": true,
    "agentOverrideBadNumber": true,
    "dispositions": [
      {
        "dispositionId": 1,
        "priority": 1
      }
    ]
  }
}
    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/skills/' +skillId,
        'type': 'PUT',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/json; charset=UTF-8',
			'Accept':'application/json, text/javascript, */*; q=0.01'
        },
        'data': JSON.stringify(PutSkillbySkillIDpayload),
        'success': function (result, status, statusCode) {
			ConstructArray("Admin","Skills","PUT /skills/{skillId}","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
            //Process success actions
            return result;
			
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","Skills","PUT /skills/{skillId}","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
			
        }
    });
}
function GetDispostionBySkillid(skillId,searchString,fields,skip,top,orderby ){//done
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/skills/' + skillId + '/dispositions'+
                 '?searchString='+ searchString+ '&fields='+ fields+ '&skip='+ skip+ '&top='+ top+ '&orderby='+ orderby ,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Skills","GET /skills/{skillId}/dispositions","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Skills","GET /skills/{skillId}/dispositions","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function GetDispostionBySkillidUnAssigned(skillId,searchString,fields,skip,top,orderby ){//done
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/skills/' + skillId + '/dispositions/unassigned' +
                 '?searchString=' + searchString + '&fields=' + fields + '&skip=' + skip + '&top=' + top + '&orderby=' + orderby ,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Skills","GET /skills/{skillId}/dispositions/unassigned","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Skills","GET /skills/{skillId}/dispositions/unassigned","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function GetSkillParameterGeneralSetting(skillId,fields ){	//done
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/skills/'+ skillId+ '/parameters/general-settings'+ '?fields='+ fields,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Skills","GET /skills/{skillId}/parameters/general-settings","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Skills","GET /skills/{skillId}/parameters/general-settings","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function PutSkillParameterGeneralSetting(skillId){//done

var SkillGeneralSettingPayload = {
  "generalSettings": {
    "minimumRetryMinutes": 12,
    "maximumAttempts": 10,
    "defaultContactExpiration": 10,
    "getPriorityContactsOnContactinsertion": false,
    "loadCallbacks": false,
    "loadFresh": false,
    "loadNonFresh": false,
    "overrideBusinessUnitAbandonRate": false,
    "maximumRingingDuration": 1,
    "beginDampenPercentage": 1,
    "abandonRateCutoff": 1,
    "abandonRateThreshold": 1,
    "inactiveBlenderTimer": 1,
    "maximumRatio": 1,
    "aggressiveness": "conservative",
    "endOfListNotificationsDelay": 15,
    "notifyAgentsWhenListIsEmpty": false,
    "percentageOfAgentsBeforeOverdial": 5,
    "blockMultipleCalls": true,
    "consecutiveAttemptsWithoutALiveConnect": 5
  }
}
    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/skills/' + skillId + '/parameters/general-settings',
        'type': 'PUT',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/json; charset=UTF-8',
			'Accept':'application/json, text/javascript, */*; q=0.01'
        },
        'data': JSON.stringify(SkillGeneralSettingPayload),
        'success': function (result, status, statusCode) {
			ConstructArray("Admin","Skills","PUT /skills/{skillId}/parameters/general-settings","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
            //Process success actions
            return result;
			
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","Skills","PUT /skills/{skillId}/parameters/general-settings","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
			
        }
    });
}

//Admin--> Contacts

function GetcontactbyContactID(contactId,fields ){	//done
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/contacts/' + contactId + '/files' + '?fields='+ fields,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Contacts","GET /contacts/{contactId}/files","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Contacts","GET /contacts/{contactId}/files","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}

//Admin--> List

function GetListCalllist(fields,top,skip,orderBy,startDate,endDate ){	//done

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/lists/call-lists/jobs'+
                    '?fields='+ fields+ '&top='+ top+'&skip='+ skip+ '&orderBy='+ orderBy+ '&startDate='+ startDate+ '&endDate='+ endDate,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","LIST","GET /lists/call-lists/jobs","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","LIST","GET /lists/call-lists/jobs","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function PostCallListbyListID(listId,skillId,fileName,forceOverwrite,defaultTimeZone,expirationDate,listFile,startSkill){//done

var PostCallListbyListIDpayload ={
  "skillId": skillId,
  "fileName": fileName,
  "forceOverwrite": forceOverwrite,
  "defaultTimeZone": defaultTimeZone,
  "expirationDate": expirationDate,
  "listFile": listFile,
  "startSkill": startSkill
}

    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/lists/call-lists/' + listId + '/upload',
        'type': 'POST',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/json; charset=UTF-8'
        },
        'data': JSON.stringify(PostCallListbyListIDpayload),
        'success': function (result, status, statusCode) {
            //Process success actions
			ConstructArray("Admin","LIST","POST /lists/call-lists/{listId}/upload","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
            return result;
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","LIST","POST /lists/call-lists/{listId}/upload","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
        }
    });
}
function DeleteCallListByJobID(jobId) {//done

    $.ajax({
        //The baseURI variable is created by the result.resource_server_base_uri,
        //which is returned when getting a token and should be used to create the URL base
        'url': baseURI + '/services/v11.0/lists/call-lists/jobs/' +jobId,
        'type': 'DELETE',
        'headers': {
            //Use access_token previously retrieved from inContact token service
            'Authorization': 'bearer ' + accessToken,
            'content-Type': 'application/x-www-form-urlencoded'
        },
        'success': function (result, status, statusCode) {
            //Process success actions
			ConstructArray("Admin","LIST","DELETE /lists/call-lists/jobs/{jobId}","SC1-v11.0",statusCode.status + ":" + statusCode.statusTex);
            return result;
        },
        'error': function (XMLHttpRequest, textStatus, errorThrown) {
            //Process error actions
			ConstructArray("Admin","LIST","DELETE /lists/call-lists/jobs/{jobId}","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
            return false;
        }
    });
}
function GetCallingListbyJobID(jobId,fields){	//done

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/lists/call-lists/jobs/' + jobId + '?fields=' + fields,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/x-www-form-urlencoded'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","LIST","GET /lists/call-lists/jobs/{jobId}","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","LIST","GET /lists/call-lists/jobs/{jobId}","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}

//Admin --> Groups

function GetGroups(top,skip,orderby,searchString,isActive,fields){	//done

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/groups' + '?top=' + top + '&skip=' + skip+ 
        '&orderby=' + orderby + '&searchString=' + searchString + '&isActive='+ isActive + '&fields=' + fields,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Groups","GET /groups","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Groups","GET /groups","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function PostGroups(groupName, isActive, notes){	//done

var updateGroupPayload ={
  "groups": [
    {
      "groupName": groupName,
      "isActive": isActive,
      "notes": notes
    }
  ]
}

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/groups',
		'type': 'POST',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'data': JSON.stringify(updateGroupPayload),
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Groups","POST /groups","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Groups","POST /groups","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function GetGroupsByGroupID(groupId, fields){	//done

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/groups/' + groupId + '?fields='+ fields,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Groups","GET /groups/{groupId}","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Groups","GET /groups/{groupId}","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function PutGroupsByGroupID(groupId,groupName,isActive,notes){	//done
var PostGroupbyGroupIDPayload = {
  "groupName": groupName,
  "isActive": isActive,
  "notes": notes
}
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/groups/' + groupId,
		'type': 'put',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'data': JSON.stringify(PostGroupbyGroupIDPayload),
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Groups","POST /groups/{groupId}","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Groups","POST /groups/{groupId}","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function DeleteGroupsByAgentGroupID(groupId, agentId){	//done

var DeleteGroupbyGroupIDagentPayload = {"agents": [{"agentId": agentId} ] }
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/groups/'+ groupId +'/agents',
		'type': 'DELETE',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'data': JSON.stringify(DeleteGroupbyGroupIDagentPayload),
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Groups","DELETE /groups/{groupId}/agents","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Groups","DELETE /groups/{groupId}/agents","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function GetGroupsByAgentGroupID(groupId,top,skip,orderBy,searchString,assigned,fields){	//done

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/{version}/groups/' + groupId + '/agents' +'?top=' + top + '&skip=' + skip + '&orderby=' + orderBy + '&searchString=' + searchString + '&assigned=' + assigned + '&fields=' + fields,
		'type': 'GET',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Groups","GET /groups/{groupId}/agents","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Groups","GET /groups/{groupId}/agents","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function PostGroupsByAgentGroupID(groupId,agentId){	//done

var PostGroupbyGroupIDagentPayload = { "agents": [ { "agentId": 1 } ] }
	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/groups/'+ groupId +'/agents',
		'type': 'POST',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'data': JSON.stringify(PostGroupbyGroupIDagentPayload),
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Admin","Groups","POST /groups/{groupId}/agents","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Admin","Groups","POST /groups/{groupId}/agents","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}

//Agent --> Chat Request

function postSessionIdInteractionsContactIdtyping(sessionId, contactId,isTyping= true,isTextEntered= true){	//done

var PostChatTypingPayload = {
  "isTyping": isTyping,
  "isTextEntered": isTextEntered
}

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/agent-sessions/' + sessionId + '/interactions/'+ contactId +'/typing',
		'type': 'POST',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'data': JSON.stringify(PostChatTypingPayload),
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Agents","Chat","POST /agent-sessions/{sessionId}/interactions/{contactId}/typing","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Agents","Chat","POST /agent-sessions/{sessionId}/interactions/{contactId}/typing","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function posttAgentSessionSessionIdInteractionAddEmail(sessionId){	//done

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/agent-sessions/'+ sessionId + '/interactions/add-email',
		'type': 'POST',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Agents","Email","POST /agent-sessions/{sessionId}/interactions/add-email","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Agents","Email","/agent-sessions/{sessionId}/interactions/add-email","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function posttAgentSessionIdInteractionConatactIdParkemail(sessionId,ConatctId,toAddress="",fromAddress="",ccAddress="",
           bccAddress="",subject="", bodyHtml="",attachments="",attachmentNames="",isDraft="false",originalAttachmentNames=""){//done

var PostEmailParkPayload = {
  "toAddress": toAddress,
  "fromAddress": fromAddress,
  "ccAddress": ccAddress,
  "bccAddress": bccAddress,
  "subject": subject,
  "bodyHtml": bodyHtml,
  "attachments": attachments,
  "attachmentNames": attachmentNames,
  "isDraft": isDraft,
  "originalAttachmentNames": originalAttachmentNames
}

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/agent-sessions/' + sessionId + '/interactions/' + ConatctId+ '/email-park',
		'type': 'POST',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'data': JSON.stringify(PostEmailParkPayload),
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Agents","Email","POST /agent-sessions/{sessionId}/interactions/{contactId}/email-park","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Agents","Email","POST /agent-sessions/{sessionId}/interactions/{contactId}/email-park","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function posttAgentSessionIdInteractionConatactIdUnparkemail( sessionId, ConatctId, isImmediate="false"){

var PostEmailunParkPayload = { "isImmediate": isImmediate }

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/agent-sessions/' + sessionId + '/interactions/' + ConatctId+ '/email-unpark',
		'type': 'POST',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'data': JSON.stringify(PostEmailunParkPayload),
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Agents","Email","POST /agent-sessions/{sessionId}/interactions/{contactId}/email-unpark","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Agents","Email","POST /agent-sessions/{sessionId}/interactions/{contactId}/email-unpark","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function posttAgentSessionIdInteractionConatactIdPreview( sessionId, ConatctId){//done


	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/agent-sessions/' + sessionId + '/interactions/' + ConatctId+ '/email-preview',
		'type': 'POST',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Agents","Email","POST /agent-sessions/{sessionId}/interactions/{contactId}/email-preview","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Agents","Email","POST /agent-sessions/{sessionId}/interactions/{contactId}/email-preview","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function posttAgentSessionIdInteractionConatactIdEmailRestore( sessionId, ConatctId){// done

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/services/v11.0/agent-sessions/' + sessionId + '/interactions/' + ConatctId+ '/email-restore',
		'type': 'POST',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Agents","Email","POST /agent-sessions/{sessionId}/interactions/{contactId}/email-restore","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Agents","Email","POST /agent-sessions/{sessionId}/interactions/{contactId}/email-restore","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
function posttAgentSessionIdInteractionConatactIdSnooze( sessionId, callbackId){// done

	$.ajax({
		//The baseURI variable is created by the result.resource_server_base_uri,
		//which is returned when getting a token and should be used to create the URL base
		'url': baseURI + '/agent-sessions/' + sessionId '/interactions/'+ callbackId '/dial',
		'type': 'POST',
		'headers': {
			//Use access_token previously retrieved from inContact token service
			'Authorization': 'bearer ' + accessToken,
			'content-Type': 'application/json; charset=UTF-8'
		},
		'success': function (result, status, statusCode) {
			//Process success actions
			ConstructArray("Agents","PersonalCon","POST /agent-sessions/{sessionId}/interactions/{callbackId}/dial","SC1-v11.0",statusCode.status + ":" + statusCode.statusText);
			return result;
		},
		'error': function (XMLHttpRequest, textStatus, errorThrown) {
			//Process error actions
			ConstructArray("Agents","PersonalCon","POST /agent-sessions/{sessionId}/interactions/{callbackId}/dial","SC1-v11.0",XMLHttpRequest.status+ ":" + errorThrown);
			return false;
			
		}
	});
}
